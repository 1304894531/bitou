/* BOSS直聘一键检索沟通助手 - Background Service Worker */
const SEARCH_BASE_URL = "https://www.zhipin.com/web/geek/jobs";

const cityCodeMap = {
  "全国": "100010000",
  "北京": "101010100",
  "上海": "101020100",
  "天津": "101030100",
  "重庆": "101040100",
  "广州": "101280100",
  "深圳": "101280600",
  "杭州": "101210100",
  "成都": "101270100",
  "武汉": "101200100",
  "南京": "101190100",
  "苏州": "101190400",
  "西安": "101110100",
  "长沙": "101250100",
  "郑州": "101180100",
  "青岛": "101120200",
  "济南": "101120100",
  "烟台": "101120500",
  "长春": "101060100",
  "沈阳": "101070100",
  "大连": "101070200",
  "哈尔滨": "101050100",
  "石家庄": "101090100",
  "太原": "101100100",
  "合肥": "101220100",
  "福州": "101230100",
  "厦门": "101230200",
  "南昌": "101240100",
  "南宁": "101300100",
  "昆明": "101290100",
  "贵阳": "101260100",
  "海口": "101310100",
  "兰州": "101160100",
  "银川": "101170100",
  "西宁": "101150100",
  "乌鲁木齐": "101130100",
  "呼和浩特": "101080100",
  "佛山": "101280800",
  "东莞": "101281600",
  "珠海": "101280700",
  "无锡": "101190200",
  "常州": "101191100",
  "宁波": "101210400",
  "温州": "101210700",
  "嘉兴": "101210300",
  "绍兴": "101210500",
  "金华": "101210900",
  "台州": "101210600",
  "泉州": "101230500",
  "潍坊": "101120600",
  "临沂": "101120900",
  "淄博": "101120300",
  "威海": "101121300",
  "泰安": "101120800",
  "洛阳": "101180900",
  "新乡": "101180300",
  "南阳": "101180700",
  "襄阳": "101200200",
  "宜昌": "101200900",
  "株洲": "101250300",
  "湘潭": "101250200",
  "中山": "101281700",
  "惠州": "101280300",
  "江门": "101281100",
  "南通": "101190500",
  "扬州": "101190600",
  "盐城": "101190700",
  "徐州": "101190800",
  "镇江": "101190300",
  "泰州": "101191200",
  "芜湖": "101220300",
  "蚌埠": "101220200",
  "赣州": "101240700",
  "桂林": "101300500",
  "柳州": "101300300"
};

let currentScanTabId = null;
let isScanning = false;
let isApplying = false;
let lastJobs = [];
let scanAggregate = null;

chrome.runtime.onInstalled.addListener(async () => {
  try {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  } catch (error) {
    console.warn("sidePanel behavior not available", error);
  }
});

chrome.action.onClicked.addListener(async (tab) => {
  try {
    await chrome.sidePanel.open({ tabId: tab.id });
  } catch (error) {
    console.warn("open side panel failed", error);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    try {
      if (message?.type === "GET_CITY_OPTIONS") {
        sendResponse({ ok: true, cities: Object.keys(cityCodeMap) });
        return;
      }

      if (message?.type === "START_SCAN") {
        startScan(message.requirement).then((result) => {
          sendToPanel({ type: "SCAN_DONE", ...result });
        }).catch((error) => {
          sendToPanel({ type: "ERROR", message: `检索失败：${normalizeError(error)}` });
        });
        sendResponse({ ok: true });
        return;
      }

      if (message?.type === "STOP_SCAN") {
        await stopScan();
        sendResponse({ ok: true });
        return;
      }

      if (message?.type === "APPLY_SELECTED") {
        applySelectedJobs(message.jobs || []).then((result) => {
          sendToPanel({ type: "APPLY_DONE", ...result });
        }).catch((error) => {
          sendToPanel({ type: "ERROR", message: `投递失败：${normalizeError(error)}` });
        });
        sendResponse({ ok: true });
        return;
      }

      if (message?.type === "SCAN_PROGRESS" || message?.type === "APPLY_STATUS" || message?.type === "JOB_CARDS_UPDATED") {
        if (message?.type === "SCAN_PROGRESS") {
          message = attachScanAggregate(message);
        }
        if (message?.type === "JOB_CARDS_UPDATED") {
          lastJobs = message.jobs || lastJobs;
        }
        sendToPanel(message);
        sendResponse({ ok: true });
        return;
      }

      sendResponse({ ok: false, error: "UNKNOWN_MESSAGE" });
    } catch (error) {
      sendResponse({ ok: false, error: normalizeError(error) });
    }
  })();
  return true;
});

async function startScan(requirement) {
  if (isScanning) throw new Error("正在检索中，请先停止或等待完成");
  isScanning = true;
  lastJobs = [];

  try {
    const tab = await getOrCreateActiveBossTab();
    currentScanTabId = tab.id;
    const cities = normalizeCities(requirement.cities || requirement.city || "全国");
    const allJobs = [];
    scanAggregate = {
      totalCities: cities.length,
      currentCityIndex: 0,
      currentCity: "",
      completedScanned: 0,
      completedMatched: 0,
      currentScanned: 0,
      currentMatched: 0
    };

    for (let index = 0; index < cities.length; index += 1) {
      if (!isScanning) break;
      const city = cities[index];
      scanAggregate.currentCityIndex = index + 1;
      scanAggregate.currentCity = city;
      scanAggregate.currentScanned = 0;
      scanAggregate.currentMatched = 0;
      const cityRequirement = { ...requirement, city, cities: [city] };
      const url = buildSearchUrl(cityRequirement);
      sendToPanel({ type: "LOG", message: `开始检索城市 ${index + 1}/${cities.length}：${city}` });
      sendToPanel({ type: "LOG", message: `打开职位页：${url}` });
      await navigateTab(tab.id, url);
      await waitForContentScript(tab.id, 18000);
      const result = await sendTabMessage(tab.id, { type: "SCAN_JOBS", requirement: cityRequirement, source: "background" }, 300000);
      const jobs = result?.jobs || [];
      mergeJobsInto(allJobs, jobs);
      scanAggregate.completedScanned += scanAggregate.currentScanned || 0;
      scanAggregate.completedMatched = allJobs.length;
      lastJobs = allJobs.slice();
      sendToPanel({ type: "JOB_CARDS_UPDATED", jobs: lastJobs });
      sendToPanel({
        type: "SCAN_PROGRESS",
        progress: {
          city,
          cityIndex: index + 1,
          totalCities: cities.length,
          scannedTotal: scanAggregate.currentScanned || 0,
          matchedTotal: jobs.length,
          currentCityScanned: scanAggregate.currentScanned || 0,
          currentCityMatched: jobs.length,
          totalScannedAll: scanAggregate.completedScanned,
          totalMatchedAll: scanAggregate.completedMatched,
          scrollIndex: 0,
          cityDone: true,
          unlimitedScroll: true
        },
        message: `${city} 检索完成；累计检索 ${scanAggregate.completedScanned} 个岗位，累计符合 ${scanAggregate.completedMatched} 个岗位`
      });
      if (result?.stopped || !isScanning) break;
      await sleep(randomInt(1200, 2200));
    }

    return { ok: true, jobs: lastJobs, stopped: !isScanning };
  } finally {
    isScanning = false;
    scanAggregate = null;
  }
}

function attachScanAggregate(message) {
  if (!scanAggregate || !message?.progress) return message;
  const progress = message.progress || {};
  scanAggregate.currentScanned = Number(progress.scannedTotal || scanAggregate.currentScanned || 0);
  scanAggregate.currentMatched = Number(progress.matchedTotal || scanAggregate.currentMatched || 0);
  const totalScannedAll = scanAggregate.completedScanned + scanAggregate.currentScanned;
  const totalMatchedAll = scanAggregate.completedMatched + scanAggregate.currentMatched;
  return {
    ...message,
    progress: {
      ...progress,
      city: progress.city || scanAggregate.currentCity,
      cityIndex: scanAggregate.currentCityIndex,
      totalCities: scanAggregate.totalCities,
      currentCityScanned: scanAggregate.currentScanned,
      currentCityMatched: scanAggregate.currentMatched,
      totalScannedAll,
      totalMatchedAll
    }
  };
}

async function stopScan() {
  isScanning = false;
  if (currentScanTabId) {
    try {
      await chrome.tabs.sendMessage(currentScanTabId, { type: "STOP_SCAN" });
      sendToPanel({ type: "LOG", message: "已发送停止筛选指令，已检索岗位会保留" });
    } catch (error) {
      sendToPanel({ type: "LOG", message: "当前页面暂未连接，但已停止后台筛选" });
    }
  }
}

async function applySelectedJobs(jobs) {
  if (isApplying) throw new Error("正在投递中，请勿重复点击");
  if (!jobs.length) throw new Error("请先选择要沟通的岗位");
  isApplying = true;

  let processed = 0;
  let success = 0;
  let needUserAction = 0;
  const results = [];

  try {
    const tab = await getOrCreateActiveBossTab();
    for (const job of jobs) {
      processed += 1;
      sendToPanel({
        type: "APPLY_STATUS",
        jobId: job.id,
        status: "opening_detail",
        message: `正在打开 ${processed}/${jobs.length}：${job.title || job.companyName || "岗位"}`,
        progress: { total: jobs.length, processed, success, needUserAction }
      });

      try {
        await navigateTab(tab.id, absoluteUrl(job.detailUrl));
        await waitForContentScript(tab.id, 16000);
        const result = await sendTabMessage(tab.id, { type: "APPLY_CURRENT_JOB", job }, 90000);
        if (result?.success) {
          success += 1;
          results.push({ jobId: job.id, status: "success", message: result.message || "已点击立即沟通" });
          sendToPanel({
            type: "APPLY_STATUS",
            jobId: job.id,
            status: "success",
            message: result.message || "沟通成功",
            progress: { total: jobs.length, processed, success, needUserAction }
          });
        } else if (result?.needUserAction) {
          needUserAction += 1;
          results.push({ jobId: job.id, status: "need_user_action", message: result.message || "需要人工处理" });
          sendToPanel({
            type: "APPLY_STATUS",
            jobId: job.id,
            status: "need_user_action",
            message: result.message || "需要人工处理",
            progress: { total: jobs.length, processed, success, needUserAction }
          });
        } else {
          results.push({ jobId: job.id, status: "failed", message: result?.message || "未能确认是否沟通成功" });
          sendToPanel({
            type: "APPLY_STATUS",
            jobId: job.id,
            status: "failed",
            message: result?.message || "未能确认是否沟通成功",
            progress: { total: jobs.length, processed, success, needUserAction }
          });
        }
      } catch (error) {
        const recovered = await recoverApplyAfterNavigation(tab.id, job, error);
        if (recovered?.success) {
          success += 1;
          results.push({ jobId: job.id, status: "success", message: recovered.message || "已沟通" });
          sendToPanel({
            type: "APPLY_STATUS",
            jobId: job.id,
            status: "success",
            message: recovered.message || "已沟通",
            progress: { total: jobs.length, processed, success, needUserAction }
          });
        } else if (recovered?.needUserAction) {
          needUserAction += 1;
          results.push({ jobId: job.id, status: "need_user_action", message: recovered.message || "需要人工处理" });
          sendToPanel({
            type: "APPLY_STATUS",
            jobId: job.id,
            status: "need_user_action",
            message: recovered.message || "需要人工处理",
            progress: { total: jobs.length, processed, success, needUserAction }
          });
        } else {
          results.push({ jobId: job.id, status: "failed", message: recovered?.message || normalizeError(error) });
          sendToPanel({
            type: "APPLY_STATUS",
            jobId: job.id,
            status: "failed",
            message: recovered?.message || normalizeError(error),
            progress: { total: jobs.length, processed, success, needUserAction }
          });
        }
      }

      await sleep(randomInt(1800, 3600));
    }

    return { ok: true, processed, success, needUserAction, results };
  } finally {
    isApplying = false;
  }
}


async function recoverApplyAfterNavigation(tabId, job, error) {
  const errText = normalizeError(error);
  await sleep(1800);
  let tab = null;
  try { tab = await chrome.tabs.get(tabId); } catch (e) {}
  const url = tab?.url || "";
  if (/zhipin\.com\/web\/geek\/chat/.test(url)) {
    return { success: true, message: "已进入 BOSS 沟通页，判定沟通成功" };
  }

  // 如果内容脚本仍在详情页，尝试让它补点一次“留在此页/取消跳转”按钮。
  try {
    await waitForContentScript(tabId, 5000);
    const result = await sendTabMessage(tabId, { type: "APPLY_CURRENT_JOB", job, retryAfterNavigation: true }, 45000);
    if (result?.success || result?.needUserAction) return result;
    if (result?.message) return { success: false, message: result.message };
  } catch (e) {
    // 忽略二次补救失败，继续给出更准确的失败原因。
  }

  if (/安全验证|验证码|人机验证|身份验证|未登录|登录/.test(errText)) {
    return { success: false, needUserAction: true, message: errText };
  }
  if (/message port closed|Receiving end does not exist|Could not establish connection|页面响应超时|context invalidated/i.test(errText)) {
    return { success: false, message: `点击沟通后页面发生跳转或脚本断开，但未确认进入沟通页：${errText}` };
  }
  return { success: false, message: errText };
}

function buildSearchUrl(requirement = {}) {
  const keyword = (requirement.keywords || "").split(/[，,、\s\n]+/).filter(Boolean)[0] || "";
  const city = requirement.city || "全国";
  const cityCode = /^[0-9]{6,}$/.test(city) ? city : (cityCodeMap[city] || cityCodeMap["全国"]);
  const url = new URL(SEARCH_BASE_URL);
  if (keyword) url.searchParams.set("query", keyword);
  if (cityCode) url.searchParams.set("city", cityCode);
  // BOSS 的薪资/学历/经验筛选参数经常调整，这里只用关键词+城市进结果页，其它条件在页面 DOM 层过滤。
  return url.toString();
}

function normalizeCities(value) {
  if (Array.isArray(value)) {
    const items = value.map((x) => String(x || "").trim()).filter(Boolean);
    return items.length ? Array.from(new Set(items)) : ["全国"];
  }
  const text = String(value || "").trim();
  if (!text) return ["全国"];
  const items = text.split(/[，,、\s\n]+/).map((x) => x.trim()).filter(Boolean);
  return items.length ? Array.from(new Set(items)) : ["全国"];
}

function mergeJobsInto(target, jobs) {
  const map = new Map(target.map((job) => [job.id, job]));
  for (const job of jobs || []) {
    const old = map.get(job.id);
    map.set(job.id, { ...old, ...job, status: old?.status || job.status || "pending" });
  }
  target.length = 0;
  target.push(...Array.from(map.values()));
}

async function getOrCreateActiveBossTab() {
  const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (active?.id) return active;
  const tab = await chrome.tabs.create({ url: "https://www.zhipin.com/" });
  return tab;
}

async function navigateTab(tabId, url) {
  await chrome.tabs.update(tabId, { url });
  await waitForTabComplete(tabId, 25000);
  await sleep(1600);
}

function waitForTabComplete(tabId, timeout = 25000) {
  return new Promise((resolve, reject) => {
    let done = false;
    const timer = setTimeout(() => {
      if (!done) {
        done = true;
        chrome.tabs.onUpdated.removeListener(listener);
        resolve(false);
      }
    }, timeout);
    const listener = (updatedTabId, changeInfo) => {
      if (updatedTabId === tabId && changeInfo.status === "complete") {
        if (!done) {
          done = true;
          clearTimeout(timer);
          chrome.tabs.onUpdated.removeListener(listener);
          resolve(true);
        }
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function waitForContentScript(tabId, timeout = 16000) {
  const start = Date.now();
  let injected = false;
  while (Date.now() - start < timeout) {
    try {
      const res = await chrome.tabs.sendMessage(tabId, { type: "PING" });
      if (res?.ok) return true;
    } catch (error) {
      if (!injected) {
        injected = true;
        try {
          await chrome.scripting.executeScript({ target: { tabId }, files: ["contentScript.js"] });
        } catch (injectError) {
          // 当前页可能不是 zhipin 页面，继续等待或最终抛错。
        }
      }
    }
    await sleep(500);
  }
  throw new Error("内容脚本未连接，请确认当前标签页是 BOSS 直聘页面，并刷新后重试");
}

function sendTabMessage(tabId, message, timeout = 60000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("页面响应超时")), timeout);
    chrome.tabs.sendMessage(tabId, message, (response) => {
      clearTimeout(timer);
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      if (response?.ok === false) {
        reject(new Error(response.error || "页面执行失败"));
        return;
      }
      resolve(response || {});
    });
  });
}

function sendToPanel(message) {
  chrome.runtime.sendMessage(message).catch(() => {});
}

function absoluteUrl(url) {
  if (!url) return "https://www.zhipin.com/";
  if (url.startsWith("http")) return url;
  return new URL(url, "https://www.zhipin.com").toString();
}

function normalizeError(error) {
  if (!error) return "未知错误";
  if (typeof error === "string") return error;
  return error.message || String(error);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
