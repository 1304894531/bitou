/* BOSS直聘一键检索沟通助手 - Background Service Worker */
const SEARCH_BASE_URL = "https://www.zhipin.com/web/geek/jobs";

const cityCodeMap = {
  "全国": "100010000",
  "北京": "101010100",
  "上海": "101020100",
  "天津": "101030100",
  "重庆": "101040100",
  "石家庄": "101090100",
  "保定": "101090200",
  "张家口": "101090300",
  "承德": "101090400",
  "唐山": "101090500",
  "廊坊": "101090600",
  "沧州": "101090700",
  "衡水": "101090800",
  "邢台": "101090900",
  "邯郸": "101091000",
  "秦皇岛": "101091100",
  "太原": "101100100",
  "大同": "101100200",
  "阳泉": "101100300",
  "晋中": "101100400",
  "长治": "101100500",
  "晋城": "101100600",
  "临汾": "101100700",
  "运城": "101100800",
  "朔州": "101100900",
  "忻州": "101101000",
  "吕梁": "101101100",
  "呼和浩特": "101080100",
  "包头": "101080200",
  "乌海": "101080300",
  "乌兰察布": "101080400",
  "通辽": "101080500",
  "赤峰": "101080600",
  "鄂尔多斯": "101080700",
  "巴彦淖尔": "101080800",
  "锡林郭勒": "101080900",
  "呼伦贝尔": "101081000",
  "兴安盟": "101081100",
  "阿拉善盟": "101081200",
  "沈阳": "101070100",
  "大连": "101070200",
  "鞍山": "101070300",
  "抚顺": "101070400",
  "本溪": "101070500",
  "丹东": "101070600",
  "锦州": "101070700",
  "营口": "101070800",
  "阜新": "101070900",
  "辽阳": "101071000",
  "铁岭": "101071100",
  "朝阳": "101071200",
  "盘锦": "101071300",
  "葫芦岛": "101071400",
  "长春": "101060100",
  "吉林市": "101060200",
  "延边": "101060300",
  "四平": "101060400",
  "通化": "101060500",
  "白城": "101060600",
  "辽源": "101060700",
  "松原": "101060800",
  "白山": "101060900",
  "哈尔滨": "101050100",
  "齐齐哈尔": "101050200",
  "牡丹江": "101050300",
  "佳木斯": "101050400",
  "绥化": "101050500",
  "黑河": "101050600",
  "大兴安岭": "101050700",
  "伊春": "101050800",
  "大庆": "101050900",
  "七台河": "101051000",
  "鸡西": "101051100",
  "鹤岗": "101051200",
  "双鸭山": "101051300",
  "南京": "101190100",
  "无锡": "101190200",
  "镇江": "101190300",
  "苏州": "101190400",
  "南通": "101190500",
  "扬州": "101190600",
  "盐城": "101190700",
  "徐州": "101190800",
  "淮安": "101190900",
  "连云港": "101191000",
  "常州": "101191100",
  "泰州": "101191200",
  "宿迁": "101191300",
  "昆山": "101190404",
  "常熟": "101190402",
  "江阴": "101190202",
  "张家港": "101190403",
  "杭州": "101210100",
  "湖州": "101210200",
  "嘉兴": "101210300",
  "宁波": "101210400",
  "绍兴": "101210500",
  "台州": "101210600",
  "温州": "101210700",
  "丽水": "101210800",
  "金华": "101210900",
  "衢州": "101211000",
  "舟山": "101211100",
  "义乌": "101210904",
  "慈溪": "101210403",
  "余姚": "101210404",
  "合肥": "101220100",
  "蚌埠": "101220200",
  "芜湖": "101220300",
  "淮南": "101220400",
  "马鞍山": "101220500",
  "安庆": "101220600",
  "宿州": "101220700",
  "阜阳": "101220800",
  "亳州": "101220900",
  "黄山": "101221000",
  "滁州": "101221100",
  "淮北": "101221200",
  "铜陵": "101221300",
  "宣城": "101221400",
  "六安": "101221500",
  "池州": "101221700",
  "福州": "101230100",
  "厦门": "101230200",
  "宁德": "101230300",
  "莆田": "101230400",
  "泉州": "101230500",
  "漳州": "101230600",
  "龙岩": "101230700",
  "三明": "101230800",
  "南平": "101230900",
  "南昌": "101240100",
  "九江": "101240200",
  "上饶": "101240300",
  "抚州": "101240400",
  "宜春": "101240500",
  "吉安": "101240600",
  "赣州": "101240700",
  "景德镇": "101240800",
  "萍乡": "101240900",
  "新余": "101241000",
  "鹰潭": "101241100",
  "济南": "101120100",
  "青岛": "101120200",
  "淄博": "101120300",
  "德州": "101120400",
  "烟台": "101120500",
  "潍坊": "101120600",
  "济宁": "101120700",
  "泰安": "101120800",
  "临沂": "101120900",
  "菏泽": "101121000",
  "滨州": "101121100",
  "东营": "101121200",
  "威海": "101121300",
  "枣庄": "101121400",
  "日照": "101121500",
  "莱芜": "101121600",
  "聊城": "101121700",
  "郑州": "101180100",
  "安阳": "101180200",
  "新乡": "101180300",
  "许昌": "101180400",
  "平顶山": "101180500",
  "信阳": "101180600",
  "南阳": "101180700",
  "开封": "101180800",
  "洛阳": "101180900",
  "商丘": "101181000",
  "焦作": "101181100",
  "鹤壁": "101181200",
  "濮阳": "101181300",
  "周口": "101181400",
  "漯河": "101181500",
  "驻马店": "101181600",
  "三门峡": "101181700",
  "济源": "101181800",
  "武汉": "101200100",
  "襄阳": "101200200",
  "鄂州": "101200300",
  "孝感": "101200400",
  "黄冈": "101200500",
  "黄石": "101200600",
  "咸宁": "101200700",
  "荆州": "101200800",
  "宜昌": "101200900",
  "恩施": "101201000",
  "十堰": "101201100",
  "神农架": "101201200",
  "随州": "101201300",
  "荆门": "101201400",
  "天门": "101201500",
  "仙桃": "101201600",
  "潜江": "101201700",
  "长沙": "101250100",
  "湘潭": "101250200",
  "株洲": "101250300",
  "衡阳": "101250400",
  "郴州": "101250500",
  "常德": "101250600",
  "益阳": "101250700",
  "娄底": "101250800",
  "邵阳": "101250900",
  "岳阳": "101251000",
  "张家界": "101251100",
  "怀化": "101251200",
  "永州": "101251400",
  "湘西": "101251500",
  "广州": "101280100",
  "韶关": "101280200",
  "惠州": "101280300",
  "梅州": "101280400",
  "汕头": "101280500",
  "深圳": "101280600",
  "珠海": "101280700",
  "佛山": "101280800",
  "肇庆": "101280900",
  "湛江": "101281000",
  "江门": "101281100",
  "河源": "101281200",
  "清远": "101281300",
  "云浮": "101281400",
  "潮州": "101281500",
  "东莞": "101281600",
  "中山": "101281700",
  "阳江": "101281800",
  "揭阳": "101281900",
  "茂名": "101282000",
  "汕尾": "101282100",
  "南宁": "101300100",
  "崇左": "101300200",
  "柳州": "101300300",
  "来宾": "101300400",
  "桂林": "101300500",
  "梧州": "101300600",
  "贺州": "101300700",
  "贵港": "101300800",
  "玉林": "101300900",
  "百色": "101301000",
  "钦州": "101301100",
  "河池": "101301200",
  "北海": "101301300",
  "防城港": "101301400",
  "海口": "101310100",
  "三亚": "101310200",
  "三沙": "101310301",
  "儋州": "101310205",
  "琼海": "101310211",
  "文昌": "101310212",
  "万宁": "101310215",
  "东方": "101310202",
  "成都": "101270100",
  "攀枝花": "101270200",
  "自贡": "101270300",
  "绵阳": "101270400",
  "南充": "101270500",
  "达州": "101270600",
  "遂宁": "101270700",
  "广安": "101270800",
  "巴中": "101270900",
  "泸州": "101271000",
  "宜宾": "101271100",
  "内江": "101271200",
  "资阳": "101271300",
  "乐山": "101271400",
  "眉山": "101271500",
  "凉山": "101271600",
  "雅安": "101271700",
  "甘孜": "101271800",
  "阿坝": "101271900",
  "德阳": "101272000",
  "广元": "101272100",
  "贵阳": "101260100",
  "遵义": "101260200",
  "安顺": "101260300",
  "黔南": "101260400",
  "黔东南": "101260500",
  "铜仁": "101260600",
  "毕节": "101260700",
  "六盘水": "101260800",
  "黔西南": "101260900",
  "昆明": "101290100",
  "大理": "101290200",
  "红河": "101290300",
  "曲靖": "101290400",
  "保山": "101290500",
  "文山": "101290600",
  "玉溪": "101290700",
  "楚雄": "101290800",
  "普洱": "101290900",
  "昭通": "101291000",
  "临沧": "101291100",
  "怒江": "101291200",
  "迪庆": "101291300",
  "丽江": "101291400",
  "德宏": "101291500",
  "西双版纳": "101291600",
  "拉萨": "101140100",
  "日喀则": "101140200",
  "山南": "101140300",
  "林芝": "101140400",
  "昌都": "101140500",
  "那曲": "101140600",
  "阿里": "101140700",
  "西安": "101110100",
  "咸阳": "101110200",
  "延安": "101110300",
  "榆林": "101110400",
  "渭南": "101110500",
  "商洛": "101110600",
  "安康": "101110700",
  "汉中": "101110800",
  "宝鸡": "101110900",
  "铜川": "101111000",
  "杨凌": "101111101",
  "兰州": "101160100",
  "定西": "101160200",
  "平凉": "101160300",
  "庆阳": "101160400",
  "武威": "101160500",
  "金昌": "101160600",
  "张掖": "101160700",
  "酒泉": "101160800",
  "天水": "101160900",
  "陇南": "101161000",
  "临夏": "101161100",
  "甘南": "101161200",
  "白银": "101161300",
  "嘉峪关": "101161400",
  "西宁": "101150100",
  "海东": "101150200",
  "黄南": "101150300",
  "海南州": "101150400",
  "果洛": "101150500",
  "玉树": "101150600",
  "海西": "101150700",
  "海北": "101150800",
  "银川": "101170100",
  "石嘴山": "101170200",
  "吴忠": "101170300",
  "固原": "101170400",
  "中卫": "101170500",
  "乌鲁木齐": "101130100",
  "克拉玛依": "101130200",
  "石河子": "101130300",
  "昌吉": "101130400",
  "吐鲁番": "101130500",
  "巴音郭楞": "101130600",
  "库尔勒": "101130601",
  "阿克苏": "101130800",
  "喀什": "101130900",
  "伊犁": "101131000",
  "塔城": "101131100",
  "哈密": "101131200",
  "和田": "101131300",
  "阿勒泰": "101131400",
  "克孜勒苏": "101131500",
  "博尔塔拉": "101131600",
  "香港": "101320101",
  "澳门": "101330101",
  "台北": "101340101",
  "高雄": "101340201",
  "台中": "101340401",
  "台南": "101340203"
};

let currentScanTabId = null;
let isScanning = false;
let isApplying = false;
let lastJobs = [];
let scanAggregate = null;

chrome.runtime.onInstalled.addListener(async () => {
  try {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  } catch (error) {
    console.warn("sidePanel behavior not available", error);
  }
});

chrome.action.onClicked.addListener(async (tab) => {
  try {
    await chrome.sidePanel.open({ tabId: tab.id });
  } catch (error) {
    console.warn("open side panel failed", error);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    try {
      if (message?.type === "GET_CITY_OPTIONS") {
        sendResponse({ ok: true, cities: Object.keys(cityCodeMap) });
        return;
      }

      if (message?.type === "START_SCAN") {
        startScan(message.requirement).then((result) => {
          sendToPanel({ type: "SCAN_DONE", ...result });
        }).catch((error) => {
          sendToPanel({ type: "ERROR", message: `检索失败：${normalizeError(error)}` });
        });
        sendResponse({ ok: true });
        return;
      }

      if (message?.type === "STOP_SCAN") {
        await stopScan();
        sendResponse({ ok: true });
        return;
      }

      if (message?.type === "APPLY_SELECTED") {
        applySelectedJobs(message.jobs || []).then((result) => {
          sendToPanel({ type: "APPLY_DONE", ...result });
        }).catch((error) => {
          sendToPanel({ type: "ERROR", message: `投递失败：${normalizeError(error)}` });
        });
        sendResponse({ ok: true });
        return;
      }

      if (message?.type === "SCAN_PROGRESS" || message?.type === "APPLY_STATUS" || message?.type === "JOB_CARDS_UPDATED") {
        if (message?.type === "SCAN_PROGRESS") {
          message = attachScanAggregate(message);
        }
        if (message?.type === "JOB_CARDS_UPDATED") {
          lastJobs = message.jobs || lastJobs;
        }
        sendToPanel(message);
        sendResponse({ ok: true });
        return;
      }

      sendResponse({ ok: false, error: "UNKNOWN_MESSAGE" });
    } catch (error) {
      sendResponse({ ok: false, error: normalizeError(error) });
    }
  })();
  return true;
});

async function startScan(requirement) {
  if (isScanning) throw new Error("正在检索中，请先停止或等待完成");
  isScanning = true;
  lastJobs = [];

  try {
    const tab = await getOrCreateActiveBossTab();
    currentScanTabId = tab.id;
    const cities = normalizeCities(requirement.cities || requirement.city || "全国");
    const allJobs = [];
    scanAggregate = {
      totalCities: cities.length,
      currentCityIndex: 0,
      currentCity: "",
      completedScanned: 0,
      completedMatched: 0,
      currentScanned: 0,
      currentMatched: 0
    };

    for (let index = 0; index < cities.length; index += 1) {
      if (!isScanning) break;
      const city = cities[index];
      scanAggregate.currentCityIndex = index + 1;
      scanAggregate.currentCity = city;
      scanAggregate.currentScanned = 0;
      scanAggregate.currentMatched = 0;
      const cityRequirement = { ...requirement, city, cities: [city] };
      const url = buildSearchUrl(cityRequirement);
      sendToPanel({ type: "LOG", message: `开始检索城市 ${index + 1}/${cities.length}：${city}` });
      sendToPanel({ type: "LOG", message: `打开职位页：${url}` });
      await navigateTab(tab.id, url);
      await waitForContentScript(tab.id, 18000);
      const result = await sendTabMessage(tab.id, { type: "SCAN_JOBS", requirement: cityRequirement, source: "background" }, 300000);
      const jobs = result?.jobs || [];
      mergeJobsInto(allJobs, jobs);
      scanAggregate.completedScanned += scanAggregate.currentScanned || 0;
      scanAggregate.completedMatched = allJobs.length;
      lastJobs = allJobs.slice();
      sendToPanel({ type: "JOB_CARDS_UPDATED", jobs: lastJobs });
      sendToPanel({
        type: "SCAN_PROGRESS",
        progress: {
          city,
          cityIndex: index + 1,
          totalCities: cities.length,
          scannedTotal: scanAggregate.currentScanned || 0,
          matchedTotal: jobs.length,
          currentCityScanned: scanAggregate.currentScanned || 0,
          currentCityMatched: jobs.length,
          totalScannedAll: scanAggregate.completedScanned,
          totalMatchedAll: scanAggregate.completedMatched,
          scrollIndex: 0,
          cityDone: true,
          unlimitedScroll: true
        },
        message: `${city} 检索完成；累计检索 ${scanAggregate.completedScanned} 个岗位，累计符合 ${scanAggregate.completedMatched} 个岗位`
      });
      if (result?.stopped || !isScanning) break;
      await sleep(randomInt(1200, 2200));
    }

    return { ok: true, jobs: lastJobs, stopped: !isScanning };
  } finally {
    isScanning = false;
    scanAggregate = null;
  }
}

function attachScanAggregate(message) {
  if (!scanAggregate || !message?.progress) return message;
  const progress = message.progress || {};
  scanAggregate.currentScanned = Number(progress.scannedTotal || scanAggregate.currentScanned || 0);
  scanAggregate.currentMatched = Number(progress.matchedTotal || scanAggregate.currentMatched || 0);
  const totalScannedAll = scanAggregate.completedScanned + scanAggregate.currentScanned;
  const totalMatchedAll = scanAggregate.completedMatched + scanAggregate.currentMatched;
  return {
    ...message,
    progress: {
      ...progress,
      city: progress.city || scanAggregate.currentCity,
      cityIndex: scanAggregate.currentCityIndex,
      totalCities: scanAggregate.totalCities,
      currentCityScanned: scanAggregate.currentScanned,
      currentCityMatched: scanAggregate.currentMatched,
      totalScannedAll,
      totalMatchedAll
    }
  };
}

async function stopScan() {
  isScanning = false;
  if (currentScanTabId) {
    try {
      await chrome.tabs.sendMessage(currentScanTabId, { type: "STOP_SCAN" });
      sendToPanel({ type: "LOG", message: "已发送停止筛选指令，已检索岗位会保留" });
    } catch (error) {
      sendToPanel({ type: "LOG", message: "当前页面暂未连接，但已停止后台筛选" });
    }
  }
}

async function applySelectedJobs(jobs) {
  if (isApplying) throw new Error("正在投递中，请勿重复点击");
  if (!jobs.length) throw new Error("请先选择要沟通的岗位");
  isApplying = true;

  let processed = 0;
  let success = 0;
  let needUserAction = 0;
  const results = [];

  try {
    const tab = await getOrCreateActiveBossTab();
    for (const job of jobs) {
      processed += 1;
      sendToPanel({
        type: "APPLY_STATUS",
        jobId: job.id,
        status: "opening_detail",
        message: `正在打开 ${processed}/${jobs.length}：${job.title || job.companyName || "岗位"}`,
        progress: { total: jobs.length, processed, success, needUserAction }
      });

      try {
        await navigateTab(tab.id, absoluteUrl(job.detailUrl));
        await waitForContentScript(tab.id, 16000);
        const result = await sendTabMessage(tab.id, { type: "APPLY_CURRENT_JOB", job }, 90000);
        if (result?.success) {
          success += 1;
          results.push({ jobId: job.id, status: "success", message: result.message || "已点击立即沟通" });
          sendToPanel({
            type: "APPLY_STATUS",
            jobId: job.id,
            status: "success",
            message: result.message || "沟通成功",
            progress: { total: jobs.length, processed, success, needUserAction }
          });
        } else if (result?.needUserAction) {
          needUserAction += 1;
          results.push({ jobId: job.id, status: "need_user_action", message: result.message || "需要人工处理" });
          sendToPanel({
            type: "APPLY_STATUS",
            jobId: job.id,
            status: "need_user_action",
            message: result.message || "需要人工处理",
            progress: { total: jobs.length, processed, success, needUserAction }
          });
        } else {
          results.push({ jobId: job.id, status: "failed", message: result?.message || "未能确认是否沟通成功" });
          sendToPanel({
            type: "APPLY_STATUS",
            jobId: job.id,
            status: "failed",
            message: result?.message || "未能确认是否沟通成功",
            progress: { total: jobs.length, processed, success, needUserAction }
          });
        }
      } catch (error) {
        const recovered = await recoverApplyAfterNavigation(tab.id, job, error);
        if (recovered?.success) {
          success += 1;
          results.push({ jobId: job.id, status: "success", message: recovered.message || "已沟通" });
          sendToPanel({
            type: "APPLY_STATUS",
            jobId: job.id,
            status: "success",
            message: recovered.message || "已沟通",
            progress: { total: jobs.length, processed, success, needUserAction }
          });
        } else if (recovered?.needUserAction) {
          needUserAction += 1;
          results.push({ jobId: job.id, status: "need_user_action", message: recovered.message || "需要人工处理" });
          sendToPanel({
            type: "APPLY_STATUS",
            jobId: job.id,
            status: "need_user_action",
            message: recovered.message || "需要人工处理",
            progress: { total: jobs.length, processed, success, needUserAction }
          });
        } else {
          results.push({ jobId: job.id, status: "failed", message: recovered?.message || normalizeError(error) });
          sendToPanel({
            type: "APPLY_STATUS",
            jobId: job.id,
            status: "failed",
            message: recovered?.message || normalizeError(error),
            progress: { total: jobs.length, processed, success, needUserAction }
          });
        }
      }

      await sleep(randomInt(1800, 3600));
    }

    return { ok: true, processed, success, needUserAction, results };
  } finally {
    isApplying = false;
  }
}


async function recoverApplyAfterNavigation(tabId, job, error) {
  const errText = normalizeError(error);
  await sleep(1800);
  let tab = null;
  try { tab = await chrome.tabs.get(tabId); } catch (e) {}
  const url = tab?.url || "";
  if (/zhipin\.com\/web\/geek\/chat/.test(url)) {
    return { success: true, message: "已进入 BOSS 沟通页，判定沟通成功" };
  }

  // 如果内容脚本仍在详情页，尝试让它补点一次“留在此页/取消跳转”按钮。
  try {
    await waitForContentScript(tabId, 5000);
    const result = await sendTabMessage(tabId, { type: "APPLY_CURRENT_JOB", job, retryAfterNavigation: true }, 45000);
    if (result?.success || result?.needUserAction) return result;
    if (result?.message) return { success: false, message: result.message };
  } catch (e) {
    // 忽略二次补救失败，继续给出更准确的失败原因。
  }

  if (/安全验证|验证码|人机验证|身份验证|未登录|登录/.test(errText)) {
    return { success: false, needUserAction: true, message: errText };
  }
  if (/message port closed|Receiving end does not exist|Could not establish connection|页面响应超时|context invalidated/i.test(errText)) {
    return { success: false, message: `点击沟通后页面发生跳转或脚本断开，但未确认进入沟通页：${errText}` };
  }
  return { success: false, message: errText };
}

function buildSearchUrl(requirement = {}) {
  const keyword = (requirement.keywords || "").split(/[，,、\s\n]+/).filter(Boolean)[0] || "";
  const city = requirement.city || "全国";
  const cityCode = /^[0-9]{6,}$/.test(city) ? city : (cityCodeMap[city] || cityCodeMap["全国"]);
  const url = new URL(SEARCH_BASE_URL);
  if (keyword) url.searchParams.set("query", keyword);
  if (cityCode) url.searchParams.set("city", cityCode);
  // BOSS 的薪资/学历/经验筛选参数经常调整，这里只用关键词+城市进结果页，其它条件在页面 DOM 层过滤。
  return url.toString();
}

function normalizeCities(value) {
  if (Array.isArray(value)) {
    const items = value.map((x) => String(x || "").trim()).filter(Boolean);
    return items.length ? Array.from(new Set(items)) : ["全国"];
  }
  const text = String(value || "").trim();
  if (!text) return ["全国"];
  const items = text.split(/[，,、\s\n]+/).map((x) => x.trim()).filter(Boolean);
  return items.length ? Array.from(new Set(items)) : ["全国"];
}

function mergeJobsInto(target, jobs) {
  const map = new Map(target.map((job) => [job.id, job]));
  for (const job of jobs || []) {
    const old = map.get(job.id);
    map.set(job.id, { ...old, ...job, status: old?.status || job.status || "pending" });
  }
  target.length = 0;
  target.push(...Array.from(map.values()));
}

async function getOrCreateActiveBossTab() {
  const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (active?.id) return active;
  const tab = await chrome.tabs.create({ url: "https://www.zhipin.com/" });
  return tab;
}

async function navigateTab(tabId, url) {
  await chrome.tabs.update(tabId, { url });
  await waitForTabComplete(tabId, 25000);
  await sleep(1600);
}

function waitForTabComplete(tabId, timeout = 25000) {
  return new Promise((resolve, reject) => {
    let done = false;
    const timer = setTimeout(() => {
      if (!done) {
        done = true;
        chrome.tabs.onUpdated.removeListener(listener);
        resolve(false);
      }
    }, timeout);
    const listener = (updatedTabId, changeInfo) => {
      if (updatedTabId === tabId && changeInfo.status === "complete") {
        if (!done) {
          done = true;
          clearTimeout(timer);
          chrome.tabs.onUpdated.removeListener(listener);
          resolve(true);
        }
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function waitForContentScript(tabId, timeout = 16000) {
  const start = Date.now();
  let injected = false;
  while (Date.now() - start < timeout) {
    try {
      const res = await chrome.tabs.sendMessage(tabId, { type: "PING" });
      if (res?.ok) return true;
    } catch (error) {
      if (!injected) {
        injected = true;
        try {
          await chrome.scripting.executeScript({ target: { tabId }, files: ["contentScript.js"] });
        } catch (injectError) {
          // 当前页可能不是 zhipin 页面，继续等待或最终抛错。
        }
      }
    }
    await sleep(500);
  }
  throw new Error("内容脚本未连接，请确认当前标签页是 BOSS 直聘页面，并刷新后重试");
}

function sendTabMessage(tabId, message, timeout = 60000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("页面响应超时")), timeout);
    chrome.tabs.sendMessage(tabId, message, (response) => {
      clearTimeout(timer);
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      if (response?.ok === false) {
        reject(new Error(response.error || "页面执行失败"));
        return;
      }
      resolve(response || {});
    });
  });
}

function sendToPanel(message) {
  chrome.runtime.sendMessage(message).catch(() => {});
}

function absoluteUrl(url) {
  if (!url) return "https://www.zhipin.com/";
  if (url.startsWith("http")) return url;
  return new URL(url, "https://www.zhipin.com").toString();
}

function normalizeError(error) {
  if (!error) return "未知错误";
  if (typeof error === "string") return error;
  return error.message || String(error);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
