/* BOSS直聘一键检索沟通助手 - Content Script */
(function () {
  if (window.__BOSS_ONE_CLICK_CONTENT_LOADED__) return;
  window.__BOSS_ONE_CLICK_CONTENT_LOADED__ = true;

  let abortScan = false;
  const detailInfoCache = new Map();

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    (async () => {
      try {
        if (message?.type === "PING") {
          sendResponse({ ok: true, url: location.href, title: document.title });
          return;
        }
        if (message?.type === "STOP_SCAN") {
          abortScan = true;
          sendResponse({ ok: true });
          return;
        }
        if (message?.type === "SCAN_JOBS") {
          abortScan = false;
          const result = await scanJobs(message.requirement || {});
          sendResponse({ ok: true, ...result });
          return;
        }
        if (message?.type === "APPLY_CURRENT_JOB") {
          const result = await applyCurrentJob(message.job || {});
          sendResponse({ ok: true, ...result });
          return;
        }
        sendResponse({ ok: false, error: "UNKNOWN_CONTENT_MESSAGE" });
      } catch (error) {
        sendResponse({ ok: false, error: normalizeError(error) });
      }
    })();
    return true;
  });

  async function scanJobs(requirement) {
    const allJobs = [];
    const seenMatched = new Set();
    const seenRaw = new Set();
    let scrollIndex = 0;
    let stableRounds = 0;

    await waitForPageReady();
    await sleep(1000);
    const scrollBox = findJobListScrollBox();

    while (!abortScan) {
      await sleep(500);

      const cards = await parseJobCardsOnPage(requirement);
      let newRaw = 0;
      let newMatched = 0;

      for (const raw of cards.rawJobs) {
        if (!seenRaw.has(raw.id)) {
          seenRaw.add(raw.id);
          newRaw += 1;
        }
      }

      for (const job of cards.jobs) {
        if (!seenMatched.has(job.id)) {
          seenMatched.add(job.id);
          allJobs.push(job);
          newMatched += 1;
        }
      }

      emit({
        type: "SCAN_PROGRESS",
        progress: {
          pageIndex: scrollIndex + 1,
          scrollIndex: scrollIndex + 1,
          maxScrolls: 0,
          scannedTotal: seenRaw.size,
          matchedTotal: allJobs.length,
          currentPageScanned: newRaw,
          currentPageMatched: newMatched,
          city: requirement.city || "当前城市",
          stopped: abortScan,
          unlimitedScroll: true
        },
        message: `${requirement.city || "当前城市"} 第 ${scrollIndex + 1} 次下滑：新增检索 ${newRaw} 个，新增符合 ${newMatched} 个`
      });
      emit({ type: "JOB_CARDS_UPDATED", jobs: allJobs });

      if (abortScan) break;

      const moved = await scrollJobListOnce(scrollBox);
      // BOSS 是滚动加载/虚拟列表：不再设置固定最大下滑次数。
      // 只有在连续多轮“滑不动或没有新增岗位”时，才认为已经到底。
      if (!moved || (newRaw === 0 && newMatched === 0)) stableRounds += 1;
      else stableRounds = 0;

      if (stableRounds >= 5) {
        emit({
          type: "SCAN_PROGRESS",
          progress: {
            pageIndex: scrollIndex + 1,
            scrollIndex: scrollIndex + 1,
            maxScrolls: 0,
            scannedTotal: seenRaw.size,
            matchedTotal: allJobs.length,
            city: requirement.city || "当前城市",
            stopped: abortScan,
            unlimitedScroll: true,
            reachedEnd: true
          },
          message: `${requirement.city || "当前城市"} 已连续多次无新增岗位，判断已到底，停止当前城市检索`
        });
        break;
      }

      scrollIndex += 1;
      await sleep(randomInt(900, 1600));
    }

    return { jobs: allJobs, stopped: abortScan };
  }

  async function parseJobCardsOnPage(requirement) {
    const candidateCards = findCandidateJobCards();
    const rawJobs = [];
    const jobs = [];
    const seenRawInView = new Set();

    for (let index = 0; index < candidateCards.length; index += 1) {
      const card = candidateCards[index];
      let job = parseOneCard(card, index);
      if (!job || !job.detailUrl || seenRawInView.has(job.id)) continue;

      // 新策略：左侧卡片只负责拿 detailUrl；岗位名称、薪资、公司、地点等核心字段从“查看更多信息/详情页”读取。
      // 这样避免 BOSS SPA 左侧卡片 class 不稳定导致公司名/薪资漏识别。
      const detailInfo = await enrichJobFromDetailPage(job);
      job = mergeJobWithDetail(job, detailInfo);

      seenRawInView.add(job.id);
      rawJobs.push(job);

      const match = matchJob(job, requirement);
      if (match.matched) {
        jobs.push({
          ...job,
          city: requirement.city || job.location || "",
          matchScore: match.score,
          matchReason: match.reason,
          status: "pending"
        });
      }
    }

    return { rawJobs, jobs, rawCount: rawJobs.length };
  }

  async function enrichJobFromDetailPage(job) {
    const url = absoluteUrl(job.detailUrl || "");
    if (!url) return {};
    const cacheKey = url.replace(/[?#].*$/, "");
    if (detailInfoCache.has(cacheKey)) return detailInfoCache.get(cacheKey);

    const empty = {};
    try {
      const response = await fetch(url, {
        method: "GET",
        credentials: "include",
        cache: "no-store",
        redirect: "follow"
      });

      if (!response.ok) {
        detailInfoCache.set(cacheKey, empty);
        return empty;
      }

      const html = await response.text();
      const info = parseDetailHtml(html, url);
      detailInfoCache.set(cacheKey, info);

      // 控制请求节奏，避免过快读取详情页。
      await sleep(randomInt(120, 280));
      return info;
    } catch (error) {
      detailInfoCache.set(cacheKey, empty);
      return empty;
    }
  }

  function parseDetailHtml(html, url = "") {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");

    const scriptJobInfo = extractJobInfoFromHtml(html);
    const metaDescription = doc.querySelector('meta[name="description"]')?.getAttribute("content") || "";
    const metaKeywords = doc.querySelector('meta[name="keywords"]')?.getAttribute("content") || "";
    const pageTitle = doc.querySelector("title")?.textContent || "";

    const title =
      scriptJobInfo.job_name ||
      pickTextFromDoc(doc, [".job-primary .name h1", ".smallbanner .job-title", ".job-title", "h1"]) ||
      parseFromMeta(metaDescription, /(.+?)招聘[，,]/) ||
      "";

    const salary =
      scriptJobInfo.job_salary ||
      cleanSalaryText(pickTextFromDoc(doc, [".job-primary .name .salary", ".job-primary .salary", ".smallbanner .badge", ".salary"])) ||
      cleanSalaryText(metaDescription) ||
      "";

    const company =
      scriptJobInfo.company ||
      pickCompanyFromDetailDoc(doc) ||
      parseFromMeta(metaDescription, /^(.+?)招聘/) ||
      "";

    const location =
      pickTextFromDoc(doc, [".job-primary .text-city", ".text-city"]) ||
      parseFromMeta(metaDescription, /地点[：:]\s*([^，,]+)/) ||
      "";

    const experience =
      pickTextFromDoc(doc, [".job-primary .text-experiece", ".job-primary .text-experience", ".text-experiece", ".text-experience"]) ||
      parseFromMeta(metaDescription, /要求[：:]\s*([^，,]+)/) ||
      "";

    const degree =
      pickTextFromDoc(doc, [".job-primary .text-degree", ".text-degree"]) ||
      parseFromMeta(metaDescription, /学历[：:]\s*([^，,]+)/) ||
      "";

    const welfareTags = uniqueTexts(Array.from(doc.querySelectorAll(".tag-container-new .job-tags span, .job-tags span"))
      .map((el) => normalizeText(el.textContent || el.innerText || ""))
      .filter(Boolean));

    const jobDescription =
      pickTextFromDoc(doc, [".job-detail-section .job-sec-text", ".job-detail .job-sec-text", ".job-sec-text"]) ||
      metaDescription;

    const companyDescription =
      pickTextFromDoc(doc, [".job-detail-company .company-info-box .job-sec-text", ".company-info-box .job-sec-text"]) ||
      "";

    const bossInfo =
      pickTextFromDoc(doc, [".job-boss-info .boss-info-attr", ".boss-info-attr"]) ||
      "";

    const rawText = [
      pageTitle,
      metaDescription,
      metaKeywords,
      title,
      salary,
      company,
      location,
      experience,
      degree,
      welfareTags.join(" "),
      bossInfo,
      jobDescription,
      companyDescription
    ].filter(Boolean).join(" ");

    return {
      title: stripSalaryFromText(title) || title,
      salary,
      companyName: cleanCompanyName(company, { title, salary, location }) || company,
      location,
      experience,
      degree,
      tags: welfareTags,
      jobDescription,
      companyDescription,
      rawText,
      detailUrl: url
    };
  }

  function mergeJobWithDetail(job, detail = {}) {
    const mergedTags = uniqueTexts([...(job.tags || []), ...(detail.tags || [])])
      .filter((tag) => !cleanSalaryText(tag));

    const title = detail.title || job.title || "";
    const salary = detail.salary || job.salary || "";
    const companyName = detail.companyName || job.companyName || "";
    const location = detail.location || job.location || "";

    return {
      ...job,
      title: stripSalaryFromText(title) || stripSalaryFromText(job.title) || title || job.title,
      salary,
      companyName,
      location,
      experience: detail.experience || job.experience || "",
      degree: detail.degree || job.degree || "",
      tags: mergedTags,
      rawText: [job.rawText, detail.rawText, detail.jobDescription, detail.companyDescription].filter(Boolean).join(" "),
      detailUrl: detail.detailUrl || job.detailUrl
    };
  }

  function extractJobInfoFromHtml(html) {
    const pick = (key) => {
      const pattern = new RegExp(`${key}\\s*:\\s*(['"])(.*?)\\1`, "s");
      const match = html.match(pattern);
      return match ? decodeHtmlEntities(match[2].trim()) : "";
    };

    return {
      job_id: pick("job_id"),
      job_name: pick("job_name"),
      job_salary: pick("job_salary"),
      company: pick("company"),
      position: pick("position"),
      securityId: pick("securityId")
    };
  }

  function pickTextFromDoc(doc, selectors) {
    for (const selector of selectors) {
      const el = doc.querySelector(selector);
      const text = normalizeText(el?.textContent || el?.innerText || "");
      if (text) return text;
    }
    return "";
  }

  function pickCompanyFromDetailDoc(doc) {
    const selectors = [
      ".smallbanner .detail-op .info",
      ".sider-company .company-info a[title]",
      ".sider-company .company-info a",
      ".job-boss-info .boss-info-attr",
      ".boss-info-attr",
      ".company-info .name",
      ".company-info a"
    ];

    for (const selector of selectors) {
      const el = doc.querySelector(selector);
      if (!el) continue;

      let text = normalizeText(el.getAttribute("title") || el.textContent || el.innerText || "");
      if (!text) continue;

      text = text
        .replace(/查看所有职位.*/g, "")
        .replace(/下载App.*/g, "")
        .split("·")[0]
        .trim();

      const cleaned = cleanCompanyName(text, {});
      if (cleaned) return cleaned;
    }

    return "";
  }

  function parseFromMeta(text, pattern) {
    const match = String(text || "").match(pattern);
    return match ? normalizeText(match[1] || "") : "";
  }

  function uniqueTexts(values) {
    const seen = new Set();
    const result = [];
    for (const value of values) {
      const text = normalizeText(value || "");
      if (!text || seen.has(text)) continue;
      seen.add(text);
      result.push(text);
    }
    return result;
  }

  function decodeHtmlEntities(value) {
    const textarea = document.createElement("textarea");
    textarea.innerHTML = value || "";
    return textarea.value;
  }

  function findCandidateJobCards() {
    const selectors = [
      ".job-card-wrapper",
      ".job-card-body",
      ".job-list-box li",
      ".job-list li",
      ".search-job-result li",
      ".job-list-wrapper li",
      "li.job-card-box",
      "div[class*='job-card']",
      "li[class*='job-card']"
    ];
    const nodes = [];
    for (const selector of selectors) {
      document.querySelectorAll(selector).forEach((el) => nodes.push(el));
    }

    // 兜底：根据 job_detail 链接向上找卡片容器。
    document.querySelectorAll("a[href*='job_detail'], a[href*='/job_detail/']").forEach((a) => {
      const container = a.closest("li, .job-card-wrapper, .job-card-body, div[class*='job-card'], div[class*='card']");
      if (container) nodes.push(container);
    });

    const unique = [];
    const seen = new Set();
    for (const node of nodes) {
      if (!(node instanceof HTMLElement)) continue;
      if (seen.has(node)) continue;
      const text = normalizeText(node.innerText);
      if (!text || text.length < 8) continue;
      const hasJobLink = !!node.querySelector("a[href*='job_detail'], a[href*='/job_detail/']");
      const hasJobText = /薪|K|k|经验|本科|大专|职位|招聘|立即沟通/.test(text);
      if (!hasJobLink && !hasJobText) continue;
      seen.add(node);
      unique.push(node);
    }
    return unique;
  }

  function parseOneCard(card, index) {
    const firstLink = card.querySelector("a[href*='job_detail'], a[href*='/job_detail/']") || card.querySelector("a[href]");
    const firstDetailUrl = firstLink ? absoluteUrl(firstLink.getAttribute("href")) : "";
    if (!firstDetailUrl || !/zhipin\.com\/.*job_detail/.test(firstDetailUrl)) return null;

    // 关键：BOSS 现在是 SPA 渲染，页面源代码里没有岗位卡片；必须读取运行时 DOM。
    // 这里根据 job_detail 链接和元素在左侧列表中的可视范围，向上找到完整卡片，避免只拿到职位名小容器。
    const visualRoot = findVisualJobCardRoot(firstLink, firstDetailUrl) || card;
    const fullCard = expandToFullJobCard(visualRoot, firstDetailUrl);
    const link = fullCard.querySelector("a[href*='job_detail'], a[href*='/job_detail/']") || firstLink || fullCard.querySelector("a[href]");
    const detailUrl = link ? absoluteUrl(link.getAttribute("href")) : firstDetailUrl;
    if (!detailUrl || !/zhipin\.com\/.*job_detail/.test(detailUrl)) return null;

    const rawTitle = pickText(fullCard, [
      ".job-name",
      ".job-title",
      ".job-card-left .job-name",
      ".job-card-body .job-title",
      "[class*='job-name']",
      "[class*='job-title']"
    ]) || normalizeText(link?.innerText || "").split(/[\n]/)[0] || "未识别职位";

    // BOSS 新版经常把薪资直接放在岗位名称后边，如：
    // “时序基础模型（TSFM）算法工程师 7-12K”。
    // 所以必须先从岗位名称文本里抠薪资，再把职位名里的薪资去掉。
    // 薪资不是岗位名同一个文本节点，而是岗位名称右侧/后方的独立兄弟节点。
    // 因此先根据岗位名称元素找“同一父级/同一行/右侧最近”的薪资节点。
    const salaryNearTitle = extractSalaryAroundTitle(fullCard, link, rawTitle);
    const salaryFromTitle = cleanSalaryText(rawTitle) || cleanSalaryText(link?.innerText || "");
    const title = stripSalaryFromText(rawTitle) || "未识别职位";

    const tags = collectTags(fullCard);
    const lineInfo = parseCardLines(fullCard, { title, rawTitle, link });
    const salaryFromTags = findSalaryInTags(tags);

    let salary = salaryNearTitle || salaryFromTitle || lineInfo.salary || salaryFromTags || extractSalary(fullCard, detailUrl, { title: rawTitle, link });
    const location = lineInfo.location || pickLocation(fullCard);
    let companyName = lineInfo.companyName || extractCompanyName(fullCard, { title, salary, location, tags });

    // 如果公司名仍然没取到，用卡片文本里“地点前一行/薪资后面的短文本”兜底。
    if (!companyName) {
      companyName = inferCompanyFromLines(fullCard, { title, salary, location, tags });
    }

    // 避免薪资混进标签区重复显示。
    const cleanTags = tags.filter((tag) => !cleanSalaryText(tag) && tag !== companyName && tag !== location && tag !== title);

    const text = normalizeText(fullCard.innerText);

    return {
      id: detailUrl.replace(/[?#].*$/, "") || `job-${Date.now()}-${index}`,
      title,
      companyName,
      location,
      salary,
      tags: cleanTags,
      detailUrl,
      cardIndex: index,
      rawText: text,
      status: "pending"
    };
  }

  function findVisualJobCardRoot(link, detailUrl = "") {
    if (!(link instanceof HTMLElement)) return null;
    const candidates = [];
    let cur = link;
    for (let depth = 0; cur && depth < 12; depth += 1, cur = cur.parentElement) {
      if (!(cur instanceof HTMLElement)) continue;
      const rect = cur.getBoundingClientRect();
      const text = normalizeText(cur.innerText || cur.textContent || "");
      if (!text || text.length < 6 || text.length > 2200) continue;

      const hasSameLink = detailUrl
        ? Array.from(cur.querySelectorAll("a[href*='job_detail'], a[href*='/job_detail/']")).some((a) => sameJobUrl(absoluteUrl(a.getAttribute("href")), detailUrl))
        : true;
      if (!hasSameLink) continue;

      const salary = cleanSalaryText(text);
      const className = String(cur.className || "");
      let score = 0;
      if (salary) score += 80;
      if (/job-card|job-list|job-item|card|list-item|item/i.test(className)) score += 25;
      if (rect.width >= 220 && rect.width <= 760) score += 20;
      if (rect.height >= 55 && rect.height <= 260) score += 20;
      if (/经验|学历|本科|大专|硕士|不限/.test(text)) score += 10;
      if (/公司|科技|信息|网络|集团|有限|股份|工作室|中心|院|所|厂|店/.test(text)) score += 8;
      // 太大的容器一般是整个列表，不要选。
      if (rect.height > 360 || text.length > 1200) score -= 35;
      candidates.push({ el: cur, score, salary, textLen: text.length, height: rect.height });
    }
    candidates.sort((a, b) => b.score - a.score || a.height - b.height || a.textLen - b.textLen);
    return candidates[0]?.el || null;
  }

  function expandToFullJobCard(card, detailUrl = "") {
    if (!(card instanceof HTMLElement)) return card;

    // 如果传入的已经是通过视觉/链接定位到的完整卡片，且含薪资，直接返回。
    const initialText = normalizeText(card.innerText || card.textContent || "");
    if (cleanSalaryText(initialText) && initialText.length < 1600) return card;

    let cur = card;
    let best = card;
    const candidates = [];
    for (let depth = 0; cur && depth < 12; depth += 1, cur = cur.parentElement) {
      if (!(cur instanceof HTMLElement)) continue;
      const text = normalizeText(cur.innerText || cur.textContent || "");
      if (!text || text.length > 2600) continue;

      const hasSameLink = detailUrl
        ? Array.from(cur.querySelectorAll("a[href*='job_detail'], a[href*='/job_detail/']")).some((a) => sameJobUrl(absoluteUrl(a.getAttribute("href")), detailUrl))
        : !!cur.querySelector("a[href*='job_detail'], a[href*='/job_detail/']");
      if (!hasSameLink) continue;

      const rect = cur.getBoundingClientRect();
      const salary = cleanSalaryText(text);
      let score = 0;
      if (salary) score += 100;
      if (rect.width >= 220 && rect.width <= 760) score += 20;
      if (rect.height >= 55 && rect.height <= 260) score += 20;
      if (/经验|学历|本科|大专|硕士|不限/.test(text)) score += 8;
      if (/job-card|job-list|job-item|card|list-item|item/i.test(String(cur.className || ""))) score += 15;
      if (rect.height > 360 || text.length > 1300) score -= 40;
      candidates.push({ el: cur, score, height: rect.height, textLen: text.length });
      if (text.length > normalizeText(best.innerText || "").length && text.length < 1600) best = cur;
    }
    if (candidates.length) {
      candidates.sort((a, b) => b.score - a.score || a.height - b.height || a.textLen - b.textLen);
      return candidates[0].el;
    }

    const strongParents = [
      ".job-card-wrapper", "li.job-card-box", ".job-list-box li", ".job-list li", ".search-job-result li",
      ".job-list-wrapper li", ".rec-job-card", ".job-card-box", "[class*='job-card']", "[class*='job-list'] li"
    ];
    for (const selector of strongParents) {
      const direct = card.closest(selector);
      if (direct && direct instanceof HTMLElement) {
        const text = normalizeText(direct.innerText || "");
        if (text && text.length < 2000) return direct;
      }
    }
    return best || card;
  }

  function sameJobUrl(a, b) {
    try {
      const ua = new URL(a, location.origin);
      const ub = new URL(b, location.origin);
      return ua.pathname.replace(/\/+$/, "") === ub.pathname.replace(/\/+$/, "");
    } catch (_) {
      return String(a || "").split("?")[0] === String(b || "").split("?")[0];
    }
  }

  function extractCompanyName(card, ctx = {}) {
    const selectors = [
      ".company-name",
      "[class*='company-name']",
      ".company-text",
      ".company-info .name",
      ".company-info a",
      ".company-info",
      ".brand-name",
      "[class*='brand-name']",
      ".boss-name",
      "[class*='boss-name']",
      ".job-company",
      "[class*='job-company']",
      "[class*='company'] [class*='name']",
      "[class*='company'] a",
      ".company-logo-name",
      "[class*='logo-name']"
    ];

    for (const selector of selectors) {
      const value = cleanCompanyName(pickText(card, [selector]), ctx);
      if (value) return value;
    }

    // 兜底：新版卡片常见文本顺序为：职位、薪资、经验、学历、公司、地点。
    const inferred = inferCompanyNameFromCardText(card, ctx);
    if (inferred) return inferred;

    return "";
  }

  function cleanCompanyName(value, ctx = {}) {
    let text = normalizeText(value || "");
    if (!text) return "";

    text = text
      .replace(/\s+/g, " ")
      .replace(/^(公司|企业|品牌)[:：]/, "")
      .replace(/[\.。…]+$/g, "")
      .trim();

    // 只取公司信息中的第一段，避免把融资、规模、行业混进公司名。
    text = text.split(/[·｜|]/)[0].trim();

    const title = normalizeText(ctx.title || "");
    const salary = normalizeText(ctx.salary || "");
    const location = normalizeText(ctx.location || "");
    if (!text || text === title || text === salary || text === location) return "";
    if (text.length < 2 || text.length > 36) return "";

    const invalid = /(薪|K|k|经验|学历|大专|本科|硕士|博士|不限|年|天使轮|融资|未融资|不需要融资|人数|以上|以下|职位|招聘|立即沟通|感兴趣|查看|收藏|匹配|活跃|BOSS|直聘|发布于)/;
    if (invalid.test(text)) return "";

    const cityPattern = /(北京|上海|天津|重庆|广州|深圳|杭州|成都|武汉|南京|苏州|西安|长沙|郑州|青岛|济南|烟台|长春|沈阳|大连|哈尔滨|石家庄|太原|合肥|福州|厦门|南昌|南宁|昆明|贵阳|海口|兰州|银川|西宁|乌鲁木齐|呼和浩特|官渡|朝阳|海淀|浦东|南山|天河|余杭|高新)/;
    if (cityPattern.test(text) && /区|县|市|街|路|园|大厦/.test(text)) return "";

    return text;
  }

  function inferCompanyNameFromCardText(card, ctx = {}) {
    const text = card.innerText || "";
    const lines = text
      .split(/\n+/)
      .map((line) => normalizeText(line))
      .filter(Boolean);

    if (!lines.length) return "";

    const title = normalizeText(ctx.title || "");
    const salary = normalizeText(ctx.salary || "");
    const location = normalizeText(ctx.location || "");
    const tags = new Set((ctx.tags || []).map((t) => normalizeText(t)));

    function isBad(line) {
      if (!line || line === title || line === salary || line === location || tags.has(line)) return true;
      if (line.length < 2 || line.length > 28) return true;
      if (/(薪|K|k|经验|学历|大专|本科|硕士|博士|不限|[0-9]+-[0-9]+年|[0-9]+年|职位|招聘|立即沟通|感兴趣|查看|收藏|匹配|活跃|BOSS|直聘|发布于)/.test(line)) return true;
      if (/(北京|上海|天津|重庆|广州|深圳|杭州|成都|武汉|南京|苏州|西安|长沙|郑州|青岛|济南|烟台|长春|沈阳|大连|哈尔滨|昆明|呼和浩特).*(区|县|市|路|街|园|大厦)/.test(line)) return true;
      return false;
    }

    // 优先取地点上一行，通常就是公司名。
    const locIndex = lines.findIndex((line) => location && line.includes(location.slice(0, 2)));
    if (locIndex > 0) {
      for (let i = locIndex - 1; i >= 0; i--) {
        const name = cleanCompanyName(lines[i], ctx);
        if (name && !isBad(name)) return name;
      }
    }

    // 再从后往前找短文本公司名。
    for (let i = lines.length - 1; i >= 0; i--) {
      const name = cleanCompanyName(lines[i], ctx);
      if (name && !isBad(name)) return name;
    }

    return "";
  }

  function parseCardLines(card, ctx = {}) {
    const raw = card?.innerText || card?.textContent || "";
    const lines = raw
      .split(/\n+/)
      .map((line) => normalizeText(line))
      .filter(Boolean)
      .filter((line) => line.length <= 80);

    const title = normalizeText(ctx.title || "");
    const rawTitle = normalizeText(ctx.rawTitle || title);
    const result = { salary: "", companyName: "", location: "" };

    // 行级解析：很多 BOSS 卡片文本类似：
    // 职位名
    // 7-12K
    // 公司名
    // 郑州
    // 经验不限 学历不限
    // 或者：职位名  7-12K / 公司名  地点
    for (const line of lines) {
      if (!result.salary) {
        const s = cleanSalaryText(line);
        if (s) result.salary = s;
      }
      if (!result.location) {
        const loc = extractLocationFromLine(line);
        if (loc) result.location = loc;
      }
    }

    const titleIndex = lines.findIndex((line) => {
      if (!title) return false;
      return line.includes(title) || title.includes(line) || line.includes(rawTitle) || rawTitle.includes(line);
    });

    if (!result.salary && titleIndex >= 0) {
      for (let i = titleIndex; i < Math.min(lines.length, titleIndex + 4); i += 1) {
        const s = cleanSalaryText(lines[i]);
        if (s) { result.salary = s; break; }
      }
    }

    // 公司名通常在标题/薪资之后、地点之前，且不是经验学历福利标签。
    const candidateIndexes = [];
    if (titleIndex >= 0) {
      for (let i = titleIndex + 1; i < Math.min(lines.length, titleIndex + 8); i += 1) candidateIndexes.push(i);
    }
    for (let i = 0; i < lines.length; i += 1) candidateIndexes.push(i);

    for (const i of candidateIndexes) {
      const line = lines[i];
      const company = cleanCompanyName(line, {
        title,
        salary: result.salary,
        location: result.location,
        tags: []
      });
      if (company && !isLikelyJobTitle(company) && !looksLikeTag(company)) {
        // 如果这行包含地点，优先取地点前的公司片段。
        const loc = extractLocationFromLine(line);
        if (loc && line !== loc) {
          const beforeLoc = line.split(loc)[0].trim();
          const cleanedBefore = cleanCompanyName(beforeLoc, { title, salary: result.salary, location: loc, tags: [] });
          if (cleanedBefore) {
            result.companyName = cleanedBefore;
            if (!result.location) result.location = loc;
            break;
          }
        }
        result.companyName = company;
        break;
      }
    }

    return result;
  }

  function findSalaryInTags(tags = []) {
    for (const tag of tags) {
      const s = cleanSalaryText(tag);
      if (s) return s;
    }
    return "";
  }

  function inferCompanyFromLines(card, ctx = {}) {
    const raw = card?.innerText || card?.textContent || "";
    const lines = raw
      .split(/\n+/)
      .map((line) => normalizeText(line))
      .filter(Boolean)
      .filter((line) => line.length <= 80);

    const title = normalizeText(ctx.title || "");
    const salary = normalizeText(ctx.salary || "");
    const location = normalizeText(ctx.location || "");
    const tags = new Set((ctx.tags || []).map((x) => normalizeText(x)));

    const titleIndex = lines.findIndex((line) => title && (line.includes(title) || title.includes(line)));
    const start = titleIndex >= 0 ? titleIndex + 1 : 0;

    for (let i = start; i < Math.min(lines.length, start + 10); i += 1) {
      let line = lines[i];
      if (!line || line === title || line === salary || line === location || tags.has(line)) continue;
      if (cleanSalaryText(line) || extractLocationFromLine(line) === line || looksLikeTag(line) || isLikelyJobTitle(line)) continue;

      // 如果“公司名 地点”在同一行，切掉地点。
      const loc = extractLocationFromLine(line);
      if (loc && line.includes(loc)) {
        line = line.split(loc)[0].trim();
      }

      const name = cleanCompanyName(line, { title, salary, location, tags: Array.from(tags) });
      if (name && !looksLikeTag(name) && !isLikelyJobTitle(name)) return name;
    }

    return "";
  }

  function extractLocationFromLine(line) {
    const text = normalizeText(line || "");
    if (!text) return "";
    const cities = [
      "北京","上海","天津","重庆","广州","深圳","杭州","成都","武汉","南京","苏州","西安","长沙","郑州","青岛","济南","烟台","长春","沈阳","大连","哈尔滨","石家庄","太原","合肥","福州","厦门","南昌","南宁","昆明","贵阳","海口","兰州","银川","西宁","乌鲁木齐","呼和浩特",
      "宁波","温州","绍兴","嘉兴","无锡","常州","南通","徐州","泉州","佛山","东莞","珠海","中山","惠州","洛阳","开封","许昌","新乡","南阳","昆山"
    ];
    const hit = cities.find((city) => text.includes(city));
    if (!hit) return "";
    const districtMatch = text.match(new RegExp(`${hit}[\\u4e00-\\u9fa5A-Za-z0-9·-]{0,12}`));
    return districtMatch ? districtMatch[0] : hit;
  }

  function looksLikeTag(text) {
    const t = normalizeText(text || "");
    if (!t) return true;
    return /(经验不限|学历不限|本科|大专|硕士|博士|[0-9]+-[0-9]+年|[0-9]+年|在校|应届|五险|双休|不加班|餐补|年终奖|全职|兼职|实习|远程|面议)/.test(t);
  }

  function isLikelyJobTitle(text) {
    const t = normalizeText(text || "");
    if (!t) return false;
    return /(工程师|负责人|经理|主管|专员|助理|实习生|顾问|运营|算法|开发|测试|前端|后端|产品|设计|教师|老师|会计|销售|客服|人事|行政|文员|视觉|具身|模型|大模型)/.test(t);
  }

  function stripSalaryFromText(value) {
    let text = normalizeText(value || "");
    if (!text) return "";
    const salary = cleanSalaryText(text);
    if (!salary) return text;

    const escaped = salary.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    text = text
      .replace(new RegExp(escaped, "ig"), "")
      .replace(/\d+(?:\.\d+)?\s*-\s*\d+(?:\.\d+)?\s*[KkＫｋ](?:\s*[·・.]?\s*\d{1,2}\s*薪)?/g, "")
      .replace(/\d+(?:\.\d+)?\s*[KkＫｋ]\s*-\s*\d+(?:\.\d+)?\s*[KkＫｋ](?:\s*[·・.]?\s*\d{1,2}\s*薪)?/g, "")
      .replace(/\s{2,}/g, " ")
      .replace(/[｜|·,，、-]+$/g, "")
      .trim();
    return text;
  }

  function extractSalaryAroundTitle(card, link, rawTitle = "") {
    const titleText = normalizeText(rawTitle || "");
    const titleEl = findTitleElement(card, { title: titleText, link }) || link;
    if (!(titleEl instanceof HTMLElement)) return "";

    // A. 最优先：岗位名称元素后面的兄弟节点。
    // BOSS 新版常见结构：<职位名> <薪资红字>，二者是同一父级下的两个独立节点。
    const siblingHit = findSalaryInSiblings(titleEl);
    if (siblingHit) return siblingHit;

    // B. 查父级/祖父级所有子节点，按“标题右侧 + 同一行 + 距离近”排序。
    const rightHit = findSalaryNearTitleByGeometry(titleEl);
    if (rightHit) return rightHit;

    // C. 查标题父级、祖父级文本。用于薪资节点没有单独 class 时兜底。
    let cur = titleEl;
    for (let depth = 0; cur && depth < 8; depth += 1, cur = cur.parentElement) {
      if (!(cur instanceof HTMLElement)) continue;
      const text = cur.innerText || cur.textContent || "";
      const hit = cleanSalaryText(text);
      if (hit) return hit;
    }

    // D. 最后查整张卡片。
    const inCard = findSalaryInTextNodes(card);
    if (inCard) return inCard.salary;

    return "";
  }

  function findSalaryInSiblings(titleEl) {
    const parent = titleEl.parentElement;
    if (!parent) return "";

    // 先从 nextSibling 逐个往后找，最符合“就在岗位名称后边”的结构。
    let node = titleEl.nextSibling;
    let steps = 0;
    while (node && steps < 10) {
      const text = node.textContent || "";
      const hit = cleanSalaryText(text);
      if (hit) return hit;
      node = node.nextSibling;
      steps += 1;
    }

    // 再从 parent.children 中按 DOM 顺序找 title 后面的元素。
    const children = Array.from(parent.children).filter((el) => el instanceof HTMLElement);
    const idx = children.indexOf(titleEl);
    if (idx >= 0) {
      for (let i = idx + 1; i < Math.min(children.length, idx + 8); i += 1) {
        const el = children[i];
        if (!isVisible(el)) continue;
        const hit = cleanSalaryText(el.innerText || el.textContent || "");
        if (hit) return hit;
      }
    }

    return "";
  }

  function findSalaryNearTitleByGeometry(titleEl) {
    const titleRect = safeRect(titleEl);
    if (!titleRect) return "";

    const roots = [];
    let cur = titleEl.parentElement;
    for (let depth = 0; cur && depth < 8; depth += 1, cur = cur.parentElement) {
      if (!(cur instanceof HTMLElement)) continue;
      const text = normalizeText(cur.innerText || cur.textContent || "");
      if (!text || text.length > 1800) continue;
      roots.push(cur);
    }

    const candidates = [];
    const seen = new Set();

    for (const root of roots) {
      // 查所有元素文本，不依赖 salary class。
      root.querySelectorAll("*").forEach((el) => {
        if (!(el instanceof HTMLElement) || !isVisible(el)) return;
        const salary = cleanSalaryText(el.innerText || el.textContent || "");
        if (!salary) return;
        const rect = safeRect(el);
        if (!rect) return;
        const key = `${salary}-${Math.round(rect.left)}-${Math.round(rect.top)}`;
        if (seen.has(key)) return;
        seen.add(key);
        candidates.push({ salary, rect, el });
      });

      // 有些薪资是纯文本节点，补充 TreeWalker。
      const nodeHit = findSalaryInTextNodes(root);
      if (nodeHit?.salary && nodeHit?.el) {
        const rect = safeRect(nodeHit.el);
        if (rect) candidates.push({ salary: nodeHit.salary, rect, el: nodeHit.el });
      }
    }

    let best = null;
    let bestScore = Infinity;

    for (const item of candidates) {
      const r = item.rect;
      const vertical = Math.abs(centerY(r) - centerY(titleRect));
      const horizontal = Math.max(0, r.left - titleRect.right);
      const isRightSide = r.left >= titleRect.left;
      const sameLineBonus = vertical <= Math.max(24, titleRect.height * 1.3) ? -80 : 0;
      const rightPenalty = isRightSide ? 0 : 180;
      const distancePenalty = horizontal * 0.02;
      const score = vertical * 5 + rightPenalty + distancePenalty + sameLineBonus;

      if (score < bestScore) {
        bestScore = score;
        best = item;
      }
    }

    // 阈值放宽一点，因为侧边栏/页面缩放会导致坐标抖动。
    return best && bestScore < 360 ? best.salary : "";
  }

  function extractSalary(card, detailUrl = "", ctx = {}) {
    // 1. 先从当前卡片内所有文本找。注意：BOSS 新版薪资没有稳定 class。
    const direct = cleanSalaryText(card.innerText || card.textContent || "");
    if (direct) return direct;

    // 2. 从当前卡片内最小文本节点找，避免父节点文本过长时正则漏匹配。
    const inCardCandidate = findSalaryInTextNodes(card);
    if (inCardCandidate) return inCardCandidate.salary;

    // 3. 用布局定位：职位名和公司名能拿到，说明卡片定位没问题；
    // 薪资一般在同一行右上角，可能是兄弟节点，不在当前小容器内。
    // 这里从整页所有可见薪资文本中，选择与职位标题同一行/同一卡片附近的那个。
    const layout = findSalaryByLayout(card, ctx);
    if (layout) return layout.salary;

    // 4. 根据同一个 job_detail 链接继续向上找父级卡片。
    if (detailUrl) {
      const links = Array.from(document.querySelectorAll("a[href*='job_detail'], a[href*='/job_detail/']"))
        .filter((a) => sameJobUrl(absoluteUrl(a.getAttribute("href")), detailUrl));
      for (const link of links) {
        let cur = link;
        for (let depth = 0; cur && depth < 14; depth += 1, cur = cur.parentElement) {
          if (!(cur instanceof HTMLElement)) continue;
          const text = cur.innerText || cur.textContent || "";
          if (!text || text.length > 4500) continue;
          const hit = cleanSalaryText(text);
          if (hit) return hit;
          const nodeHit = findSalaryInTextNodes(cur);
          if (nodeHit) return nodeHit.salary;
        }
      }
    }

    return "";
  }

  function findSalaryInTextNodes(root) {
    if (!root) return null;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const raw = node.nodeValue || "";
        if (!/[KkＫｋ千万元面议]/.test(raw)) return NodeFilter.FILTER_REJECT;
        return cleanSalaryText(raw) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    let node;
    while ((node = walker.nextNode())) {
      const salary = cleanSalaryText(node.nodeValue || "");
      const el = node.parentElement;
      if (salary && el && isVisible(el)) return { salary, el };
    }
    return null;
  }

  function findSalaryByLayout(card, ctx = {}) {
    const all = collectVisibleSalaryCandidates();
    if (!all.length) return null;

    const cardRect = safeRect(card);
    const titleEl = findTitleElement(card, ctx);
    const titleRect = safeRect(titleEl);
    const linkRect = safeRect(ctx.link);

    const anchors = [titleRect, linkRect, cardRect].filter(Boolean);

    let best = null;
    let bestScore = Infinity;

    for (const item of all) {
      const r = item.rect;
      if (!r) continue;

      let score = 999999;

      // A. 在完整卡片范围内的薪资优先。
      if (cardRect && rectIntersectsLoose(cardRect, r, 8)) {
        const topScore = Math.abs(r.top - cardRect.top);
        const rightScore = Math.max(0, cardRect.right - r.right);
        score = Math.min(score, topScore + rightScore * 0.02);
      }

      // B. 和职位标题同一行、在右侧，最符合“右上角红字薪资”。
      if (titleRect) {
        const vertical = Math.abs(centerY(r) - centerY(titleRect));
        const rightSidePenalty = r.left >= titleRect.left ? 0 : 80;
        const horizontal = Math.max(0, r.left - titleRect.right);
        score = Math.min(score, vertical * 4 + horizontal * 0.03 + rightSidePenalty);
      }

      // C. 和 job_detail 链接同一行也可接受。
      if (linkRect) {
        const vertical = Math.abs(centerY(r) - centerY(linkRect));
        const rightSidePenalty = r.left >= linkRect.left ? 0 : 80;
        const horizontal = Math.max(0, r.left - linkRect.right);
        score = Math.min(score, vertical * 4 + horizontal * 0.03 + rightSidePenalty);
      }

      // 避免拿到很远处其他卡片的薪资。
      if (anchors.length) {
        const minDistance = Math.min(...anchors.map((a) => Math.abs(centerY(r) - centerY(a))));
        if (minDistance > 90) score += 500;
      }

      if (score < bestScore) {
        bestScore = score;
        best = item;
      }
    }

    return bestScore < 260 ? best : null;
  }

  function collectVisibleSalaryCandidates() {
    const candidates = [];
    const seen = new Set();

    // 先走文本节点，能拿到最小 span 文本。
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const raw = node.nodeValue || "";
        if (!/[KkＫｋ千万元面议]/.test(raw)) return NodeFilter.FILTER_REJECT;
        return cleanSalaryText(raw) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    let node;
    while ((node = walker.nextNode())) {
      const salary = cleanSalaryText(node.nodeValue || "");
      const el = node.parentElement;
      if (!salary || !el || !isVisible(el)) continue;
      const rect = safeRect(el);
      if (!rect) continue;
      const key = `${salary}-${Math.round(rect.left)}-${Math.round(rect.top)}`;
      if (seen.has(key)) continue;
      seen.add(key);
      candidates.push({ salary, el, rect });
    }

    // 再补一遍常见薪资 class。
    const selectors = [".salary", ".job-salary", "[class*='salary']", "[class*='wage']", "[class*='pay']", "[class*='price']", "[class*='money']"];
    for (const selector of selectors) {
      document.querySelectorAll(selector).forEach((el) => {
        if (!isVisible(el)) return;
        const salary = cleanSalaryText(el.innerText || el.textContent || "");
        const rect = safeRect(el);
        if (!salary || !rect) return;
        const key = `${salary}-${Math.round(rect.left)}-${Math.round(rect.top)}`;
        if (seen.has(key)) return;
        seen.add(key);
        candidates.push({ salary, el, rect });
      });
    }

    return candidates;
  }

  function findTitleElement(card, ctx = {}) {
    const selectors = [".job-name", ".job-title", "[class*='job-name']", "[class*='job-title']"];
    for (const selector of selectors) {
      const el = card?.querySelector?.(selector);
      if (el && isVisible(el)) return el;
    }

    const title = normalizeText(ctx.title || "");
    if (title) {
      const nodes = Array.from(card?.querySelectorAll?.("*") || []);
      const hit = nodes.find((el) => {
        const text = normalizeText(el.innerText || el.textContent || "");
        return text && text.length <= title.length + 8 && text.includes(title.slice(0, Math.min(6, title.length))) && isVisible(el);
      });
      if (hit) return hit;
    }

    return ctx.link instanceof HTMLElement ? ctx.link : null;
  }

  function safeRect(el) {
    if (!(el instanceof Element)) return null;
    const r = el.getBoundingClientRect();
    if (!r || r.width <= 0 || r.height <= 0) return null;
    return r;
  }

  function centerY(rect) {
    return rect.top + rect.height / 2;
  }

  function rectIntersectsLoose(a, b, padding = 0) {
    return !(b.left > a.right + padding || b.right < a.left - padding || b.top > a.bottom + padding || b.bottom < a.top - padding);
  }

  function cleanSalaryText(value) {
    let text = normalizeText(value || "")
      .replace(/[–—－~～至到]/g, "-")
      .replace(/[Ｋｋk]/g, "K")
      .replace(/\s+/g, " ")
      .trim();

    if (!text) return "";

    // 只在含薪资标志时识别，避免把 5-10年 经验当薪资。
    if (!/[K千万元薪面议]/.test(text)) return "";

    // 统一 “7 - 12 K” / “7-12 K” / “10 - 15 K · 13 薪”
    text = text
      .replace(/(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)\s*K/gi, "$1-$2K")
      .replace(/(\d+(?:\.\d+)?)\s*K\s*-\s*(\d+(?:\.\d+)?)\s*K/gi, "$1K-$2K")
      .replace(/·\s*(\d{1,2})\s*薪/g, "·$1薪");

    const patterns = [
      /\d+(?:\.\d+)?-\d+(?:\.\d+)?K(?:[·・.]?\d{1,2}薪)?/i,
      /\d+(?:\.\d+)?K-\d+(?:\.\d+)?K(?:[·・.]?\d{1,2}薪)?/i,
      /\d+(?:\.\d+)?K(?:以上|以下|起)/i,
      /\d+(?:\.\d+)?-\d+(?:\.\d+)?千(?:\/月)?/,
      /\d+(?:\.\d+)?-\d+(?:\.\d+)?万(?:\/月)?/,
      /\d{3,6}-\d{3,6}元(?:\/月)?/,
      /\d{2,5}-\d{2,5}元\/天/,
      /面议/
    ];

    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (!match) continue;
      let salary = match[0]
        .replace(/\s+/g, "")
        .replace(/[ｋk]/g, "K")
        .replace(/[–—－~～至到]/g, "-");
      if (/年$/.test(salary) && !/[K千万元薪]/i.test(salary)) continue;
      return salary;
    }

    return "";
  }

  function pickLocation(card) {
    const explicit = pickText(card, [".job-area", ".job-location", "[class*='job-area']", "[class*='location']"]);
    if (explicit) return explicit;
    const text = normalizeText(card.innerText);
    const match = text.match(/(北京|上海|天津|重庆|广州|深圳|杭州|成都|武汉|南京|苏州|西安|长沙|郑州|青岛|济南|烟台|长春|沈阳|大连|哈尔滨|石家庄|太原|合肥|福州|厦门|南昌|南宁|昆明|贵阳|海口|兰州|银川|西宁|乌鲁木齐|呼和浩特)[\w\u4e00-\u9fa5·-]{0,12}/);
    return match ? match[0] : "";
  }

  function collectTags(card) {
    const tagSelectors = [".tag-list span", ".job-card-footer span", ".job-info span", "[class*='tag'] span", "[class*='tag']"];
    const tags = [];
    tagSelectors.forEach((selector) => {
      card.querySelectorAll(selector).forEach((el) => {
        const txt = normalizeText(el.innerText || el.textContent || "");
        if (txt && txt.length <= 24 && !tags.includes(txt)) tags.push(txt);
      });
    });
    return tags.slice(0, 20);
  }

  function matchJob(job, requirement) {
    const keywords = splitWords(requirement.keywords);
    const excludes = splitWords(requirement.excludeWords);
    const text = `${job.title} ${job.companyName} ${job.location} ${job.salary} ${job.tags.join(" ")} ${job.rawText}`.toLowerCase();

    for (const word of excludes) {
      if (word && text.includes(word.toLowerCase())) {
        return { matched: false, score: 0, reason: `排除关键词：${word}` };
      }
    }

    if (keywords.length > 0) {
      const hit = keywords.filter((word) => text.includes(word.toLowerCase()));
      if (hit.length === 0) return { matched: false, score: 0, reason: "关键词不匹配" };
    }

    const minSalaryK = Number(requirement.minSalaryK || 0);
    if (minSalaryK > 0 && !salaryMeets(job.salary || job.rawText, minSalaryK)) {
      return { matched: false, score: 0, reason: `薪资低于 ${minSalaryK}K` };
    }

    const degree = requirement.degree || "不限";
    if (degree !== "不限") {
      const rank = { "不限": 0, "中专": 1, "高中": 1, "大专": 2, "本科": 3, "硕士": 4, "博士": 5 };
      const jobDegree = inferDegree(text);
      if (jobDegree && rank[jobDegree] > rank[degree]) {
        return { matched: false, score: 0, reason: `学历要求 ${jobDegree}` };
      }
    }

    const hitKeywords = keywords.filter((word) => text.includes(word.toLowerCase()));
    let score = 50 + hitKeywords.length * 20;
    if (job.salary) score += 10;
    if (job.companyName) score += 10;
    return { matched: true, score, reason: hitKeywords.length ? `关键词匹配：${hitKeywords.join("、")}` : "符合基础条件" };
  }

  function salaryMeets(salaryText, minK) {
    const text = normalizeText(salaryText).toLowerCase();
    if (!text || /面议/.test(text)) return true;
    const kRange = text.match(/(\d+(?:\.\d+)?)\s*[-~至]\s*(\d+(?:\.\d+)?)\s*k/);
    if (kRange) {
      const low = Number(kRange[1]);
      const high = Number(kRange[2]);
      return Math.max(low, high) >= minK;
    }
    const wanRange = text.match(/(\d+(?:\.\d+)?)\s*[-~至]\s*(\d+(?:\.\d+)?)\s*万/);
    if (wanRange) {
      const low = Number(wanRange[1]) * 10;
      const high = Number(wanRange[2]) * 10;
      return Math.max(low, high) >= minK;
    }
    const singleK = text.match(/(\d+(?:\.\d+)?)\s*k/);
    if (singleK) return Number(singleK[1]) >= minK;
    return true;
  }

  function inferDegree(text) {
    const order = ["博士", "硕士", "本科", "大专", "中专", "高中"];
    return order.find((d) => text.includes(d));
  }

  async function applyCurrentJob(job) {
    await waitForPageReady(18000);
    await waitForDocumentComplete(18000);
    await waitForDetailReady(18000);
    await sleep(1800);

    let pageText = normalizeText(document.body.innerText);
    if (needsLoginOrSecurityCheck(pageText)) {
      return { success: false, needUserAction: true, message: "页面需要登录或安全验证，请人工处理" };
    }

    const beforeState = detectApplySuccess();
    if (beforeState.success) return beforeState;

    let communicateButton = await waitForCommunicateButton(12000);
    if (!communicateButton) {
      if (/请先完善|绑定手机号|实名认证/.test(pageText)) {
        return { success: false, needUserAction: true, message: "需要完善账号信息后才能沟通" };
      }
      return { success: false, message: "没有找到详情页“立即沟通”按钮" };
    }

    let lastMessage = "";

    // 详情页源码中按钮为 a.btn-startchat，并带 data-url 与 redirect-url。
    // 这里按真实用户流程：点击“立即沟通” → 等弹窗 → 点击“留在此页”。
    for (let attempt = 1; attempt <= 3; attempt += 1) {
      communicateButton = findCommunicateButton() || communicateButton;
      communicateButton.scrollIntoView({ behavior: "smooth", block: "center" });
      await sleep(700);

      // 每次点击前重新确认页面没有进入验证态。
      pageText = normalizeText(document.body.innerText);
      if (needsLoginOrSecurityCheck(pageText)) {
        return { success: false, needUserAction: true, message: "触发登录或安全验证，需要人工处理" };
      }

      humanClick(communicateButton);

      const outcome = await waitForCommunicationOutcome(14000);
      if (outcome.success || outcome.needUserAction) return outcome;
      lastMessage = outcome.message || lastMessage;

      // 如果页面脚本只是把按钮状态改成已沟通，也认定成功。
      const btnText = normalizeText(communicateButton.innerText || communicateButton.textContent || "");
      const dataIsFriend = communicateButton.getAttribute?.("data-isfriend");
      if (/继续沟通|已沟通|沟通中|查看沟通/.test(btnText) || dataIsFriend === "true") {
        await maybeClickStayOnPage();
        return { success: true, message: "已点击立即沟通，按钮状态已进入沟通" };
      }

      await sleep(1000 + attempt * 400);
    }

    // 点击没有返回明确结果时，再用按钮源码里的 data-url 做同源兜底。
    const apiResult = await tryStartChatByDataUrl(findCommunicateButton() || communicateButton);
    if (apiResult.needUserAction) return apiResult;
    if (apiResult.success) {
      const stayClicked = await waitAndClickStayOnPage(4500);
      return { success: true, message: apiResult.message || (stayClicked ? "已沟通，并选择留在此页" : "已发起沟通") };
    }

    const textAfter = normalizeText(document.body.innerText);
    if (needsLoginOrSecurityCheck(textAfter)) {
      return { success: false, needUserAction: true, message: "触发安全验证或登录校验，需要人工处理" };
    }
    if (/请先完善|绑定手机号|实名认证/.test(textAfter)) {
      return { success: false, needUserAction: true, message: "需要完善账号信息或实名认证" };
    }

    return { success: false, message: apiResult.message || lastMessage || "已尝试点击立即沟通，但没有检测到留在此页弹窗或成功状态" };
  }

  async function waitForCommunicateButton(timeout = 12000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const btn = findCommunicateButton();
      if (btn) return btn;
      await sleep(350);
    }
    return null;
  }

  async function waitForCommunicationOutcome(timeout = 12000) {
    const startUrl = location.href;
    const start = Date.now();
    let clickedStay = false;
    while (Date.now() - start < timeout) {
      const stay = await maybeClickStayOnPage();
      if (stay) {
        clickedStay = true;
        await sleep(900);
        return { success: true, message: "已点击立即沟通，并选择留在此页" };
      }

      const success = detectApplySuccess();
      if (success.success) return success;

      const text = normalizeText(document.body.innerText);
      if (needsLoginOrSecurityCheck(text)) {
        return { success: false, needUserAction: true, message: "触发安全验证或登录校验，需要人工处理" };
      }
      if (/请先完善|绑定手机号|实名认证/.test(text)) {
        return { success: false, needUserAction: true, message: "需要完善账号信息或实名认证" };
      }

      if (location.href !== startUrl && /\/web\/geek\/chat/.test(location.href)) {
        return { success: true, message: "已进入沟通页面" };
      }
      await sleep(450);
    }
    return clickedStay ? { success: true, message: "已选择留在此页" } : { success: false, message: "等待沟通结果超时" };
  }

  async function waitForDocumentComplete(timeout = 18000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      if (document.readyState === "complete") return true;
      await sleep(300);
    }
    return true;
  }

  async function waitForDetailReady(timeout = 12000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      if (findCommunicateButton() || document.querySelector(".job-primary .name h1, .job-detail .job-sec-text, .btn-startchat, a[data-url*='/wapi/zpgeek/friend/add.json']")) {
        return true;
      }
      await sleep(300);
    }
    return true;
  }

  function needsLoginOrSecurityCheck(text) {
    const body = text || normalizeText(document.body?.innerText || "");
    if (/验证码|安全验证|身份验证|人机验证|访问异常|操作过于频繁|请完成验证/.test(body)) return true;

    // 不能只要页面出现“登录”就判失败：登录态页面导航里也会有“退出登录”。
    const visibleLoginForm = Array.from(document.querySelectorAll(".sign-form, .login-form, .qrcode-box, [class*='login']"))
      .some((el) => isVisible(el) && /扫码登录|短信登录|登录\/注册|使用 BOSS直聘 APP 扫码登录/.test(normalizeText(el.innerText || el.textContent || "")));
    const hasUserNav = !!document.querySelector(".nav-figure, .user-nav .label-text, a[ka='header-username']");
    return visibleLoginForm && !hasUserNav;
  }

  function findCommunicateButton() {
    const selectors = [
      ".job-op .btn-startchat",
      ".detail-op .btn-startchat",
      "a.btn-startchat[data-url*='/wapi/zpgeek/friend/add.json']",
      "a[redirect-url*='/web/geek/chat']",
      "a[data-url*='/wapi/zpgeek/friend/add.json']",
      "button[class*='startchat']",
      ".btn-startchat"
    ];
    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el && isVisible(el) && !isDisabled(el)) return el;
    }

    const texts = ["立即沟通", "继续沟通", "马上沟通", "和TA聊聊", "聊一聊"];
    const candidates = [];
    document.querySelectorAll("button, a, div, span").forEach((el) => {
      const txt = normalizeText(el.innerText || el.textContent || "");
      if (!txt || txt.length > 30) return;
      if (texts.some((t) => txt.includes(t))) candidates.push(el);
    });
    const visible = candidates.filter(isVisible).filter((el) => !isDisabled(el));
    return visible.find((el) => /BUTTON|A/.test(el.tagName)) || visible[0] || null;
  }

  async function tryStartChatByDataUrl(button) {
    try {
      const dataUrl = button?.getAttribute?.("data-url") || document.querySelector("a.btn-startchat[data-url*='/wapi/zpgeek/friend/add.json'], a[data-url*='/wapi/zpgeek/friend/add.json']")?.getAttribute("data-url");
      if (!dataUrl) return { success: false, message: "未找到详情页沟通接口 data-url" };
      const url = new URL(dataUrl, location.origin).toString();
      const res = await fetch(url, {
        method: "GET",
        credentials: "include",
        headers: {
          "Accept": "application/json, text/javascript, */*; q=0.01",
          "X-Requested-With": "XMLHttpRequest"
        }
      });
      const raw = await res.text();
      const rawText = normalizeText(raw);
      let json = null;
      try { json = raw ? JSON.parse(raw) : null; } catch (e) {}

      if (/验证码|安全验证|身份验证|人机验证|请完成验证|操作过于频繁/.test(rawText)) {
        return { success: false, needUserAction: true, message: "BOSS 返回安全验证，需要人工处理" };
      }
      if (/登录|未登录|扫码登录|login/i.test(rawText) && !/成功|已沟通|好友/.test(rawText)) {
        return { success: false, needUserAction: true, message: "登录状态失效，请重新登录 BOSS 直聘" };
      }
      if (/完善|实名认证|绑定手机号|简历/.test(rawText) && /失败|不能|请先|需要/.test(rawText)) {
        return { success: false, needUserAction: true, message: "需要完善账号、简历或实名认证" };
      }

      const code = json && (json.code ?? json.rescode ?? json.status);
      const message = normalizeText((json && (json.message || json.msg || json.toast || json.errorMsg)) || rawText);
      if (res.ok && (code === 0 || code === "0" || /成功|已沟通|好友|添加成功|ok|success/i.test(message))) {
        return { success: true, message: message || "已通过详情页接口发起沟通" };
      }
      if (res.ok && !rawText) {
        return { success: true, message: "详情页沟通接口已响应" };
      }
      if (res.ok && json && !/失败|错误|异常|限制/.test(message)) {
        return { success: true, message: message || "详情页沟通接口已响应" };
      }
      return { success: false, message: message || `详情页沟通接口响应异常：HTTP ${res.status}` };
    } catch (error) {
      return { success: false, message: `详情页沟通接口调用失败：${normalizeError(error)}` };
    }
  }

  async function waitAndClickStayOnPage(timeout = 7000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const clicked = await maybeClickStayOnPage();
      if (clicked) return true;
      await sleep(400);
    }
    return false;
  }

  async function maybeClickStayOnPage() {
    const btn = findStayOnPageButton();
    if (btn && isVisible(btn)) {
      btn.scrollIntoView?.({ behavior: "smooth", block: "center" });
      await sleep(250);
      humanClick(btn);
      await sleep(900);
      return true;
    }
    return false;
  }

  function findStayOnPageButton() {
    const stayTexts = ["留在此页", "留在当前页", "留在本页", "继续留在此页", "继续留在当前页", "继续留在网页", "留在网页", "暂不前往"];
    const clickableSelectors = [
      "button", "a", "[role='button']", ".btn", "[class*='btn']", "[class*='button']",
      ".dialog-footer span", ".dialog-footer div", ".dialog-footer a", ".dialog-footer button",
      "[class*='dialog'] span", "[class*='dialog'] div", "[class*='modal'] span", "[class*='modal'] div",
      "[class*='pop'] span", "[class*='pop'] div", "[class*='layer'] span", "[class*='layer'] div"
    ];

    const all = uniqueElements(clickableSelectors.flatMap((selector) => Array.from(document.querySelectorAll(selector))));
    const exact = all.find((el) => {
      if (!isVisible(el)) return false;
      const txt = normalizeText(el.innerText || el.textContent || "");
      return txt && txt.length <= 30 && stayTexts.some((target) => txt.includes(target));
    });
    if (exact) return closestClickable(exact);

    // 有些弹窗的按钮文案是“取消/暂不/知道了”，需要确认它处在“即将跳转沟通页”的弹窗里才点击。
    const modal = findVisibleModal();
    const modalText = normalizeText(modal?.innerText || modal?.textContent || "");
    if (modal && /前往|跳转|沟通|聊天|离开|新页面|打开/.test(modalText)) {
      const fallbackTexts = ["取消", "暂不", "知道了", "稍后", "关闭"];
      const fallback = Array.from(modal.querySelectorAll("button,a,[role='button'],.btn,[class*='btn'],span,div")).find((el) => {
        if (!isVisible(el)) return false;
        const txt = normalizeText(el.innerText || el.textContent || "");
        return txt && txt.length <= 20 && fallbackTexts.some((target) => txt.includes(target));
      });
      if (fallback) return closestClickable(fallback);
    }

    return null;
  }

  function findVisibleModal() {
    const selectors = [
      ".dialog-wrap", ".dialog-container", ".dialog-content", ".boss-dialog", ".modal", ".modal-dialog",
      ".pop", ".popup", ".pop-box", ".layer", ".toast", "[class*='dialog']", "[class*='modal']", "[class*='popup']", "[class*='popper']"
    ];
    const candidates = uniqueElements(selectors.flatMap((selector) => Array.from(document.querySelectorAll(selector))));
    return candidates.find((el) => isVisible(el) && normalizeText(el.innerText || el.textContent || "").length > 0) || null;
  }

  function closestClickable(el) {
    if (!el) return null;
    return el.closest?.("button,a,[role='button'],.btn,[class*='btn'],[class*='button']") || el;
  }

  function uniqueElements(nodes) {
    const seen = new Set();
    const out = [];
    for (const node of nodes) {
      if (!(node instanceof HTMLElement)) continue;
      if (seen.has(node)) continue;
      seen.add(node);
      out.push(node);
    }
    return out;
  }

  function detectApplySuccess() {
    const text = normalizeText(document.body.innerText);
    if (/继续沟通|已沟通|沟通中|查看沟通|沟通成功|已发送|消息已发送|投递成功|已投递|申请已提交/.test(text)) {
      return { success: true, message: "已检测到沟通/投递成功状态" };
    }
    if (/\/web\/geek\/chat/.test(location.href)) {
      return { success: true, message: "已进入沟通页面" };
    }
    const startBtn = document.querySelector(".job-op .btn-startchat, .detail-op .btn-startchat, a.btn-startchat");
    if (startBtn) {
      const btnText = normalizeText(startBtn.innerText || startBtn.textContent || "");
      const isFriend = startBtn.getAttribute?.("data-isfriend");
      if (isFriend === "true" || /继续沟通|已沟通|沟通中|查看沟通/.test(btnText)) {
        return { success: true, message: "按钮状态已变为沟通中" };
      }
    }
    const input = document.querySelector("textarea, [contenteditable='true'], .chat-input, [class*='chat-input']");
    if (input && isVisible(input)) {
      return { success: true, message: "已进入聊天窗口" };
    }
    return { success: false };
  }

  function findNextPageButton() {
    const exact = findElementByText(["下一页"], ["a", "button", "li", "span"]);
    if (exact && isVisible(exact)) return exact.closest("a,button,li") || exact;
    const selectors = [
      ".options-pages a:last-child",
      ".page a.next",
      ".pagination a.next",
      "a[ka*='page-next']",
      "button[aria-label='下一页']"
    ];
    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el && isVisible(el)) return el;
    }
    return null;
  }

  function findJobListScrollBox() {
    const selectors = [
      ".job-list-box",
      ".job-list-wrapper",
      ".search-job-result",
      ".job-list",
      "[class*='job-list']",
      "[class*='search-job']"
    ];
    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el instanceof HTMLElement && el.scrollHeight > el.clientHeight + 80) return el;
    }

    const links = Array.from(document.querySelectorAll("a[href*='job_detail'], a[href*='/job_detail/']"));
    for (const link of links) {
      let el = link.parentElement;
      while (el && el !== document.body) {
        if (el instanceof HTMLElement && el.scrollHeight > el.clientHeight + 120) return el;
        el = el.parentElement;
      }
    }
    return document.scrollingElement || document.documentElement;
  }

  async function scrollJobListOnce(scrollBox) {
    const box = scrollBox || findJobListScrollBox();
    if (!box) return false;

    if (box === document.scrollingElement || box === document.documentElement || box === document.body) {
      const before = window.scrollY || document.documentElement.scrollTop || 0;
      window.scrollBy({ top: Math.max(500, Math.floor(window.innerHeight * 0.82)), behavior: "smooth" });
      await sleep(900);
      const after = window.scrollY || document.documentElement.scrollTop || 0;
      return after > before + 20;
    }

    const before = box.scrollTop;
    box.scrollTop = Math.min(box.scrollHeight, box.scrollTop + Math.max(450, Math.floor(box.clientHeight * 0.85)));
    box.dispatchEvent(new Event("scroll", { bubbles: true }));
    await sleep(900);
    const after = box.scrollTop;
    return after > before + 20;
  }

  async function autoScrollList() {
    const scrollBox = findJobListScrollBox();
    for (let i = 0; i < 4; i++) {
      await scrollJobListOnce(scrollBox);
      await sleep(350);
    }
  }

  async function waitForListChanged(timeout = 5000) {
    const oldText = normalizeText((document.querySelector(".job-list-box") || document.body).innerText).slice(0, 500);
    const start = Date.now();
    while (Date.now() - start < timeout) {
      await sleep(400);
      const nowText = normalizeText((document.querySelector(".job-list-box") || document.body).innerText).slice(0, 500);
      if (nowText && nowText !== oldText) return true;
    }
    return false;
  }

  async function waitForPageReady(timeout = 12000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      if (document.readyState === "complete" || document.readyState === "interactive") {
        const text = normalizeText(document.body?.innerText || "");
        if (text.length > 30) return true;
      }
      await sleep(300);
    }
    return true;
  }

  function pickText(root, selectors) {
    for (const selector of selectors) {
      const el = root.querySelector(selector);
      const txt = normalizeText(el?.innerText || el?.textContent || "");
      if (txt) return txt;
    }
    return "";
  }

  function findElementByText(texts, tags = ["button", "a", "div", "span"]) {
    const nodes = Array.from(document.querySelectorAll(tags.join(",")));
    return nodes.find((el) => {
      const txt = normalizeText(el.innerText || el.textContent || "");
      return txt && txt.length <= 80 && texts.some((target) => txt.includes(target));
    }) || null;
  }

  function humanClick(el) {
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = rect.left + Math.min(rect.width - 2, Math.max(2, rect.width / 2));
    const y = rect.top + Math.min(rect.height - 2, Math.max(2, rect.height / 2));
    ["pointerdown", "mouseover", "mousemove", "mousedown", "mouseup", "click"].forEach((type) => {
      const EventCtor = type.startsWith("pointer") ? PointerEvent : MouseEvent;
      try {
        el.dispatchEvent(new EventCtor(type, { bubbles: true, cancelable: true, clientX: x, clientY: y, view: window }));
      } catch (e) {
        el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, clientX: x, clientY: y, view: window }));
      }
    });
    try {
      if (typeof el.click === "function") el.click();
    } catch (e) {}
  }

  function isVisible(el) {
    if (!el || !(el instanceof HTMLElement)) return false;
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0" && rect.width > 0 && rect.height > 0;
  }

  function isDisabled(el) {
    if (!el) return true;
    const cls = String(el.className || "");
    const attr = el.getAttribute("disabled") || el.getAttribute("aria-disabled");
    return !!attr || /disabled|disable|unable|inactive/.test(cls);
  }

  function normalizeText(text) {
    return String(text || "").replace(/\s+/g, " ").trim();
  }

  function splitWords(text) {
    return String(text || "").split(/[，,、\s\n]+/).map((s) => s.trim()).filter(Boolean);
  }

  function absoluteUrl(url) {
    if (!url) return "";
    if (url.startsWith("http")) return url;
    return new URL(url, location.origin).toString();
  }

  function emit(message) {
    try {
      chrome.runtime.sendMessage(message).catch(() => {});
    } catch (error) {}
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  function normalizeError(error) {
    if (!error) return "未知错误";
    if (typeof error === "string") return error;
    return error.message || String(error);
  }
})();
