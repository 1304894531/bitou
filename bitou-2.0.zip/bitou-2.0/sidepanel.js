const state = {
  jobs: [],
  selectedIds: new Set(),
  quickKeywords: new Set(),
  selectedCities: new Set(),
  scanning: false,
  applying: false,
};

const quickKeywordOptions = [
  "Java", "Python", "前端", "后端", "算法", "大模型", "数据分析", "产品经理", "运营", "新媒体", "行政", "人事", "党建", "辅导员", "教师", "文员"
];

const $ = (id) => document.getElementById(id);

init();

async function init() {
  renderQuickKeywords();
  await loadCities();
  bindEvents();
  addLog("插件已启动。请确保当前浏览器已登录 BOSS 直聘。", "ok");
}

async function loadCities() {
  try {
    const res = await chrome.runtime.sendMessage({ type: "GET_CITY_OPTIONS" });
    const cities = res?.cities || ["全国", "北京", "上海", "广州", "深圳"];
    renderCityOptions(cities);
  } catch (error) {
    renderCityOptions(["全国", "北京", "上海", "广州", "深圳"]);
  }
}

function renderCityOptions(cities) {
  const root = $("cityGroup");
  state.selectedCities = new Set();
  root.innerHTML = cities.map((city, idx) => {
    const checked = idx === 0 ? "checked" : "";
    if (idx === 0) state.selectedCities.add(city);
    return `<label class="check-chip"><input type="checkbox" class="city-check" value="${escapeHtml(city)}" ${checked}/> ${escapeHtml(city)}</label>`;
  }).join("");
  root.querySelectorAll(".city-check").forEach((checkbox) => {
    checkbox.addEventListener("change", () => {
      const city = checkbox.value;
      if (checkbox.checked) state.selectedCities.add(city);
      else state.selectedCities.delete(city);
      if (city === "全国" && checkbox.checked) {
        root.querySelectorAll(".city-check").forEach((item) => {
          if (item.value !== "全国") item.checked = false;
        });
        state.selectedCities = new Set(["全国"]);
      } else if (city !== "全国" && checkbox.checked) {
        const national = root.querySelector('.city-check[value="全国"]');
        if (national) national.checked = false;
        state.selectedCities.delete("全国");
      }
    });
  });
}

function renderQuickKeywords() {
  const root = $("keywordQuickGroup");
  root.innerHTML = quickKeywordOptions.map((item) => `<button type="button" class="chip" data-keyword="${escapeHtml(item)}">${escapeHtml(item)}</button>`).join("");
  root.querySelectorAll(".chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      const keyword = chip.dataset.keyword;
      if (state.quickKeywords.has(keyword)) {
        state.quickKeywords.delete(keyword);
        chip.classList.remove("active");
      } else {
        state.quickKeywords.add(keyword);
        chip.classList.add("active");
      }
    });
  });
}

function bindEvents() {
  const settingsBtn = $("settingsBtn");
  const settingsPanel = $("settingsPanel");
  if (settingsBtn && settingsPanel) {
    settingsBtn.addEventListener("click", () => {
      settingsPanel.classList.toggle("hidden");
    });
  }
  $("scanBtn").addEventListener("click", startScan);
  $("stopBtn").addEventListener("click", stopScan);
  $("selectAllBtn").addEventListener("click", selectAll);
  $("clearSelectBtn").addEventListener("click", clearSelection);
  $("applyBtn").addEventListener("click", applySelected);
  $("clearLogBtn").addEventListener("click", () => $("logs").innerHTML = "");
}

async function startScan() {
  const requirement = collectRequirement();
  if (!requirement.cities.length) {
    addLog("请至少选择一个城市。", "err");
    return;
  }
  state.scanning = true;
  state.jobs = [];
  state.selectedIds.clear();
  resetScanProgress();
  renderJobs();
  setScanning(true);
  addLog(`开始检索：${requirement.cities.join("、")} / ${requirement.keywords || "不限关键词"}`);
  try {
    const res = await chrome.runtime.sendMessage({ type: "START_SCAN", requirement });
    if (!res?.ok) addLog(res?.error || "启动失败", "err");
  } catch (error) {
    addLog(`启动失败：${error.message || error}`, "err");
    setScanning(false);
  }
}

async function stopScan() {
  addLog("正在停止筛选，已筛出来的岗位会保留显示。", "ok");
  state.scanning = false;
  setScanning(false);
  try {
    await chrome.runtime.sendMessage({ type: "STOP_SCAN" });
  } catch (error) {
    addLog(`停止指令发送失败：${error.message || error}`, "err");
  }
}

async function applySelected() {
  const selectedJobs = state.jobs.filter((job) => state.selectedIds.has(job.id));
  if (!selectedJobs.length) {
    addLog("请先勾选要立即沟通的岗位。", "err");
    return;
  }
  state.applying = true;
  setApplying(true);
  resetApplyProgress(selectedJobs.length);
  addLog(`开始沟通 ${selectedJobs.length} 个岗位。`);
  try {
    const res = await chrome.runtime.sendMessage({ type: "APPLY_SELECTED", jobs: selectedJobs });
    if (!res?.ok) addLog(res?.error || "投递启动失败", "err");
  } catch (error) {
    addLog(`投递启动失败：${error.message || error}`, "err");
    setApplying(false);
  }
}

function collectRequirement() {
  const manualKeywords = $("keywords").value.trim();
  const quick = Array.from(state.quickKeywords).join(" ");
  const cities = Array.from(state.selectedCities).filter(Boolean);
  return {
    city: cities[0] || "全国",
    cities,
    keywords: [quick, manualKeywords].filter(Boolean).join(" "),
    minSalaryK: Number($("minSalaryK").value || 0),
    degree: $("degree").value,
    maxScrolls: 0,
    maxPages: 0,
    unlimitedScroll: true,
    excludeWords: $("excludeWords").value.trim()
  };
}

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "LOG") {
    addLog(message.message || "");
  }

  if (message?.type === "ERROR") {
    addLog(message.message || "发生错误", "err");
    setScanning(false);
    setApplying(false);
  }

  if (message?.type === "SCAN_PROGRESS") {
    updateScanProgress(message.progress || {});
    if (message.message) addLog(message.message);
  }

  if (message?.type === "JOB_CARDS_UPDATED") {
    const oldSelected = new Set(state.selectedIds);
    state.jobs = mergeJobs(state.jobs, message.jobs || []);
    state.jobs.forEach((job) => {
      if (oldSelected.has(job.id)) state.selectedIds.add(job.id);
    });
    renderJobs();
  }

  if (message?.type === "SCAN_DONE") {
    state.scanning = false;
    setScanning(false);
    if (Array.isArray(message.jobs)) {
      state.jobs = mergeJobs(state.jobs, message.jobs);
      renderJobs();
    }
    addLog(message.stopped ? "筛选已停止，已保留当前结果。" : `检索完成，共 ${state.jobs.length} 个符合岗位。`, "ok");
  }

  if (message?.type === "APPLY_STATUS") {
    updateJobStatus(message.jobId, message.status, message.message);
    if (message.progress) updateApplyProgress(message.progress);
    addLog(message.message || "投递状态更新", message.status === "failed" ? "err" : "");
  }

  if (message?.type === "APPLY_DONE") {
    state.applying = false;
    setApplying(false);
    addLog(`沟通完成：已处理 ${message.processed || 0} 个，成功 ${message.success || 0} 个。`, "ok");
  }
});

function mergeJobs(oldJobs, newJobs) {
  const map = new Map(oldJobs.map((job) => [job.id, job]));
  for (const job of newJobs) {
    const old = map.get(job.id);
    map.set(job.id, { ...old, ...job, status: old?.status || job.status || "pending" });
  }
  return Array.from(map.values());
}

function renderJobs() {
  const root = $("jobsList");
  if (!state.jobs.length) {
    root.className = "jobs-list empty";
    root.innerHTML = `<div class="empty-state"><div class="empty-icon">📭</div><div class="empty-title">暂无岗位</div><div class="empty-desc">请先点击“开始检索”，筛选结果会以卡片形式展示在这里。</div></div>`;
    return;
  }
  root.className = "jobs-list";
  root.innerHTML = state.jobs.map((job) => {
    const checked = state.selectedIds.has(job.id) ? "checked" : "";
    const tags = (job.tags || []).slice(0, 8).map((tag) => `<span class="job-tag">${escapeHtml(tag)}</span>`).join("");
    const status = job.status || "pending";
    const statusText = statusMap(status);
    const salary = escapeHtml(job.salary || "薪资未标注");
    const company = escapeHtml(job.companyName || "公司未识别");
    const title = escapeHtml(job.title || "未识别职位");
    const location = escapeHtml(job.location || job.city || "地点未识别");
    const matchReason = escapeHtml(job.matchReason || "根据当前筛选条件命中");
    const lastMessage = job.lastMessage ? `<div class="job-last-message">${escapeHtml(job.lastMessage)}</div>` : "";
    return `<article class="job-card ${escapeHtml(status)}" data-id="${escapeHtml(job.id)}">
      <div class="job-card-head">
        <label class="job-select">
          <input type="checkbox" class="job-check" ${checked} aria-label="选择岗位" />
          <span></span>
        </label>
        <div class="job-title-wrap">
          <div class="job-title">${title}</div>
          <div class="job-company-row">
            <span class="job-company">${company}</span>
            <span class="job-dot">•</span>
            <span class="job-location">${location}</span>
          </div>
        </div>
        <div class="job-salary">${salary}</div>
      </div>
      <div class="job-match-row">
        <span class="match-label">匹配原因</span>
        <span class="match-text">${matchReason}</span>
      </div>
      <div class="job-tags">${tags || '<span class="job-tag muted">暂无标签</span>'}</div>
      ${lastMessage}
      <div class="job-card-foot">
        <span class="job-status ${escapeHtml(status)}">${statusText}</span>
      </div>
    </article>`;
  }).join("");

  root.querySelectorAll(".job-card").forEach((card) => {
    const id = card.dataset.id;
    const checkbox = card.querySelector(".job-check");
    checkbox.addEventListener("change", () => {
      if (checkbox.checked) state.selectedIds.add(id);
      else state.selectedIds.delete(id);
    });
    card.addEventListener("click", (event) => {
      if (event.target.closest('.job-check') || event.target.closest('.job-select')) return;
      checkbox.checked = !checkbox.checked;
      if (checkbox.checked) state.selectedIds.add(id);
      else state.selectedIds.delete(id);
      card.classList.toggle('selected', checkbox.checked);
    });
    card.classList.toggle('selected', checkbox.checked);
  });
}

function selectAll() {
  state.jobs.forEach((job) => state.selectedIds.add(job.id));
  renderJobs();
}

function clearSelection() {
  state.selectedIds.clear();
  renderJobs();
}

function updateJobStatus(jobId, status, message) {
  const job = state.jobs.find((item) => item.id === jobId);
  if (job) {
    job.status = status;
    job.lastMessage = message;
    renderJobs();
  }
}

function updateScanProgress(progress) {
  const totalScanned = progress.totalScannedAll ?? progress.scannedTotal ?? 0;
  const totalMatched = progress.totalMatchedAll ?? progress.matchedTotal ?? state.jobs.length ?? 0;
  const currentScanned = progress.currentCityScanned ?? progress.scannedTotal ?? 0;
  const currentMatched = progress.currentCityMatched ?? progress.matchedTotal ?? 0;
  const step = progress.scrollIndex || progress.pageIndex || 0;
  const cityIndex = progress.cityIndex || 0;
  const totalCities = progress.totalCities || Math.max(state.selectedCities.size, 1);

  $("scannedTotal").textContent = totalScanned;
  $("matchedTotal").textContent = totalMatched;
  $("currentCityScanned").textContent = currentScanned;
  $("currentCityMatched").textContent = currentMatched;
  $("cityIndex").textContent = cityIndex;
  $("totalCities").textContent = totalCities;
  $("pageIndex").textContent = step;

  const cityPrefix = cityIndex && totalCities ? `城市 ${cityIndex}/${totalCities}：` : "";
  const endText = progress.cityDone ? "当前城市完成" : `第 ${step || 0} 次下滑`;
  $("scanProgressText").textContent = `${cityPrefix}${progress.city || "当前城市"} ${endText}`;

  const percent = totalScanned ? Math.min(100, Math.round((totalMatched / Math.max(totalScanned, 1)) * 100)) : 0;
  $("scanProgressBar").style.width = `${percent}%`;
}

function resetScanProgress() {
  $("scannedTotal").textContent = "0";
  $("matchedTotal").textContent = "0";
  $("currentCityScanned").textContent = "0";
  $("currentCityMatched").textContent = "0";
  $("cityIndex").textContent = "0";
  $("totalCities").textContent = String(Math.max(state.selectedCities.size, 1));
  $("pageIndex").textContent = "0";
  $("scanProgressText").textContent = "准备开始";
  $("scanProgressBar").style.width = "0%";
}

function resetApplyProgress(total) {
  $("appliedTotal").textContent = "0";
  $("successTotal").textContent = "0";
  $("needUserTotal").textContent = "0";
  $("applyProgressText").textContent = `0/${total}`;
  $("applyProgressBar").style.width = "0%";
}

function updateApplyProgress(progress) {
  const total = progress.total || 0;
  const processed = progress.processed || 0;
  const success = progress.success || 0;
  const needUserAction = progress.needUserAction || 0;
  $("appliedTotal").textContent = processed;
  $("successTotal").textContent = success;
  $("needUserTotal").textContent = needUserAction;
  $("applyProgressText").textContent = `${processed}/${total}`;
  $("applyProgressBar").style.width = total ? `${Math.min(100, Math.round(processed / total * 100))}%` : "0%";
}

function setScanning(flag) {
  state.scanning = flag;
  $("scanBtn").disabled = flag;
  $("stopBtn").disabled = !flag;
}

function setApplying(flag) {
  state.applying = flag;
  $("applyBtn").disabled = flag;
}

function addLog(message, cls = "") {
  const logs = $("logs");
  const time = new Date().toLocaleTimeString("zh-CN", { hour12: false });
  const div = document.createElement("div");
  div.className = `log-line ${cls}`;
  div.textContent = `${time} ${message}`;
  logs.prepend(div);
}

function statusMap(status) {
  const map = {
    pending: "pending",
    opening_detail: "打开中",
    applying: "沟通中",
    success: "成功",
    failed: "失败",
    need_user_action: "需人工",
    skipped: "跳过"
  };
  return map[status] || status;
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"]/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch]));
}
